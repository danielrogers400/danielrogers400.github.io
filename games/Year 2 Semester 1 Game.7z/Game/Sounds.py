import pygame

class InGameSounds():
    def __init__(self, playSounds):
        if pygame.mixer:
            pygame.mixer.init()
            self.bulletFire = pygame.mixer.Sound("sounds/foo.mp3")
            self.explosion = pygame.mixer.Sound("sounds/Explosion.wav")
            self.engineNoise = pygame.mixer.Sound("sounds/engine.ogg")
            if playSounds:
                self.engineNoise.play(-1)
            self.playSounds = playSounds
        
    def playExplosion(self):
        if pygame.mixer:  
            if self.playSounds:    
                self.explosion.play()