"""This file handles ammunition functionality
Preferably, bullets would inherit common functionality from a super class
Same goes for other objects, at present they can't see each other which is making code awkward
"""
import pygame
import math

class Basic_Bullet(pygame.sprite.Sprite):
    """
    Bullet used by player
    """
    def __init__(self, screen):
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = pygame.image.load("sprites/bullet.gif")
        self.rect = self.image.get_rect()
        self.x = 1000
        self.y = 1000
        self.dx = 0
        #self.dy = 0
        self.speed = 0
        self.rect.center = (self.x, self.y)
        self.can_fire = True
        
    def update(self):
        self.checkBounds()
        self.updatePosition()
        
    def updatePosition(self): 
        self.rect.center = (self.x, self.y);
        self.y += self.speed * -1
        #self.posy += self.dy
        
    def fire(self, startX, startY, speed):
        self.x = startX
        self.y = startY
        self.speed = speed
        self.can_fire = False
        
    def checkBounds(self):
        screen = self.screen
        if self.x > screen.get_width():
            self.reset()
        if self.x < 0:
            self.reset()
        if self.y > screen.get_height():
            self.reset()
        if self.y < 0:
            self.reset()
            
    def reset(self):
        self.x = 1000
        self.y = 1000
        self.rect.center = (self.x, self.y);
        self.dx = 0
        #self.dy = 0
        self.speed = 0
        self.can_fire = True

class Enemy_Bullet(pygame.sprite.Sprite):
    """
    Bullet used by enemy planes
    """
    def __init__(self, screen):
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = pygame.image.load("sprites/enemy_bullet.gif")
        """"A copy of the image is saved on initialisation.  The bullet sprite is 
        then set to this image when it is reset; this saves making calculations
        to determine the proper orientation of the bullet after it has already been rotated
        """
        self.imageCopy = pygame.image.load("sprites/enemy_bullet.gif")
        self.rect = self.image.get_rect()
        self.x = 1500
        self.y = 1500
        self.dx = 0
        self.dy = 0
        self.speed = 0
        self.rect.center = (self.x, self.y)
        self.can_fire = True
        
    def rotate(self, dir):
        oldCenter = self.rect.center
        self.image = pygame.transform.rotate(self.image, dir)
        self.rect = self.image.get_rect()
        self.rect.center = oldCenter
        
    def update(self):
        self.checkBounds()
        self.updatePosition()
        
    def updatePosition(self): 
        self.x += self.dx
        self.y += self.dy
        self.rect.center = (self.x, self.y);
        
    def fire(self, startX, startY, direction):
        #reset the bullet first, as it may have been fired while still on screen (from the previous firing),
        #which would mean it hadn't previously reset
        self.reset()
        self.rotate(direction)
        self.dir = direction
        self.bulletSpeed = 7.0
        dirInRadians = self.dir * math.pi / 180.0
        
        self.dx = self.bulletSpeed * math.cos(dirInRadians)
        self.dy = self.bulletSpeed * math.sin(dirInRadians)  * -1.0
        
        self.x = startX
        self.y = startY
        self.can_fire = False
        
    def checkBounds(self):
        screen = self.screen
        if self.x > screen.get_width():
            self.reset()
        if self.x < 0:
            self.reset()
        if self.y > screen.get_height():
            self.reset()
        if self.y < 0:
            self.reset()
            
    def reset(self):
        self.image = self.imageCopy
        self.x = 1500
        self.y = 1500
        self.rect.center = (self.x, self.y);
        self.dx = 0
        #self.dy = 0
        self.speed = 0