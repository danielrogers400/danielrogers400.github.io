"""
This class handles score keeping and current level
Needed it's own class so it can be accessed by all files.
"""

class Scores():
    def __init__(self):
        self.CurrentScore = 0
        self.currentLevel = 0
        self.toNextLevel = 0