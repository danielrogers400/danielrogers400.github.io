import pygame
import random

class HealthPickup(pygame.sprite.Sprite):
    """
    A basic health pickup.
    It does not reset until it it 500 pixels off the screen, and the resets 500 pixels above
    the screen.  This means it isn't constantly on the screen, making it more challenging
    """
    def __init__(self, screen):
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = pygame.image.load("sprites/health.gif")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()
        self.reset()

    def update(self):
        self.rect.centerx += self.dx
        self.rect.centery += self.dy
        if self.rect.top > self.screen.get_height() + 500:
            self.reset()
    
    def reset(self):
        self.rect.bottom = -500
        self.rect.centerx = random.randrange(0, self.screen.get_width())
        self.dy = random.randrange(2, 7)
        self.dx = 0