import pygame

class Ocean(pygame.sprite.Sprite):
    def __init__(self, screen):
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = pygame.image.load("sprites/ocean.gif")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()
        self.dy = 5
        self.reset()
        
    def update(self):
        self.rect.bottom += self.dy
        if self.rect.top >= 0:
            self.reset() 
    
    def reset(self):
        self.rect.bottom = self.screen.get_height()        
