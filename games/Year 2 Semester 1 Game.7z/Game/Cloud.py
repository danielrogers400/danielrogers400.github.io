import pygame
import random

class Cloud(pygame.sprite.Sprite):
    """
    Moving cloud object.
    Has no collisions, is only a visual effect
    """
    def __init__(self, screen):
        pygame.sprite.Sprite.__init__(self)
        self.screen = screen
        self.image = pygame.image.load("sprites/Cloud.gif")
        self.image = self.image.convert()
        self.rect = self.image.get_rect()
        self.reset()

    def update(self):
        self.rect.centerx += self.dx
        self.rect.centery += self.dy
        if self.rect.top > self.screen.get_height():
            self.reset()
    
    def reset(self):
        self.rect.bottom = 0
        self.rect.centerx = random.randrange(0, self.screen.get_width())
        self.dy = random.randrange(2, 7)
        self.dx = random.randrange(-2, 2)
        