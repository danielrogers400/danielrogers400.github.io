
#import all modules used by the game    
#import Ocean
import pygame
import Ammunition
import Planes
import Sounds
import math
import Score
import Cloud
import Pickups

pygame.init()

screen = pygame.display.set_mode((800, 600))

def roundup(x):
    """
    Rounds a number up to the nearest hundred
    """
    return int(math.ceil(x / 100.0)) * 100

def game():
    pygame.display.set_caption("My plane game")

    #Create and draw background
    background = pygame.Surface(screen.get_size())
    background.fill((0, 0, 255))
    screen.blit(background, (0, 0))
    
    #Object creation
    #Array of Basic_Bullet Objects.  Multiple bullet objects used to avoid creating and destroying
    #bullets as they are fired and destroyed
    playerBulletsArray = [Ammunition.Basic_Bullet(screen) for i in range (10)]
    
    enemyBulletsArray = [Ammunition.Enemy_Bullet(screen) for i in range (4)]
    
    clouds = Cloud.Cloud(screen)
    healthPickup = Pickups.HealthPickup(screen)
    scores = Score.Scores()
    plane = Planes.PlayersPlane(playerBulletsArray, screen) #players plane
    enemyplane = Planes.EnemyPlaneBasic(screen, scores) #Enemy plane template
    enemyPlaneLvl2 = Planes.EnemyPlaneLevel2(screen, scores)
    enemyPlaneLevel3 = Planes.EnemyPlaneLevel3(screen, scores, enemyBulletsArray)
    sounds = Sounds.InGameSounds(True)
    
    allSprites = pygame.sprite.Group(healthPickup, clouds, enemyPlaneLevel3, enemyplane, enemyPlaneLvl2, plane, enemyBulletsArray[0], enemyBulletsArray[1], enemyBulletsArray[2], enemyBulletsArray[3], playerBulletsArray[0], playerBulletsArray[1], playerBulletsArray[2], playerBulletsArray[3], playerBulletsArray[4], playerBulletsArray[5], playerBulletsArray[6], playerBulletsArray[7], playerBulletsArray[8], playerBulletsArray[9])
    
    scores.toNextLevel = 500
    pointsToNextLevel = scores.toNextLevel
    
    clock = pygame.time.Clock()
    keepGoing = True
    while keepGoing:
        clock.tick(30)
        #keep the score variable updated, as scores.CurrentScore cannot be interpolated
        score = scores.CurrentScore
        pygame.mouse.set_visible(True)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                keepGoing = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    plane.fireBullet()
                elif event.key == pygame.K_ESCAPE:
                    return score
        

        
        allSprites.clear(screen, background)
        allSprites.update()
        

        
        #check collisions
        #player bullet collisions with enemy planes
        for bullet in playerBulletsArray:
            if bullet.rect.colliderect(enemyplane.rect):
                enemyplane.health -= 50
                if enemyplane.health <= 0:
                    enemyplane.reset()
                    scores.CurrentScore += 100
                    scores.toNextLevel -= 100
                bullet.reset()
            elif bullet.rect.colliderect(enemyPlaneLvl2.rect):
                enemyPlaneLvl2.health -= 50
                if enemyPlaneLvl2.health <= 0:
                    enemyPlaneLvl2.reset()
                    scores.CurrentScore += 150
                    scores.toNextLevel -= 150
                bullet.reset()
            elif bullet.rect.colliderect(enemyPlaneLevel3.rect):
                enemyPlaneLevel3.health -= 50
                if enemyPlaneLevel3.health <= 0:
                    enemyPlaneLevel3.reset()
                    scores.CurrentScore += 150
                    scores.toNextLevel -= 150
                bullet.reset()
            
        #enemy bullet collisions with player plane and players bullet
        for bullet in enemyBulletsArray:
            if bullet.rect.colliderect(plane.rect):
                sounds.playExplosion()
                bullet.reset()
                plane.health -= 10
                if plane.health <= 0:
                    keepGoing = False
                    allSprites.clear(screen, background)
                    return score
            else:  
                for playersBullet in playerBulletsArray:
                    if bullet.rect.colliderect(playersBullet.rect):
                        sounds.playExplosion()
                        bullet.reset()
                        playersBullet.reset()
            
        #enemy plane collisions with players plane
        if enemyplane.rect.colliderect(plane.rect):
            sounds.playExplosion()
            enemyplane.reset()
            plane.health -= 10
            if plane.health <= 0:
                keepGoing = False
                screen.blit(background, (0, 0))
                return score
            
        if enemyPlaneLvl2.rect.colliderect(plane.rect):
            sounds.playExplosion()
            enemyPlaneLvl2.reset()
            plane.health -= 10
            if plane.health <= 0:
                keepGoing = False
                allSprites.clear(screen, background)
                return score
        if enemyPlaneLevel3.rect.colliderect(plane.rect):
            sounds.playExplosion()
            enemyPlaneLevel3.reset()
            plane.health -= 10
            if plane.health <= 0:
                keepGoing = False
                allSprites.clear(screen, background)
                return score
            
        #health pickups
        if healthPickup.rect.colliderect(plane.rect):
            healthPickup.reset()
            if plane.health <= 80:
                plane.health += 20
            
        #UI stuff
        if scores.toNextLevel <= 0:
            scores.currentLevel += 1
            scores.toNextLevel = roundup(scores.CurrentScore * 0.8)
                
        myFont = pygame.font.SysFont("Comic Sans MS", 15, 1)
        currentLevel = scores.currentLevel
        pointsToNextLevel = scores.toNextLevel
        scoreLabel = myFont.render("Score: %(score)d" %vars(), 1, (255, 255, 0))
        levelLabel = myFont.render("Level: %(currentLevel)d" %vars(), 1, (255, 255, 0))
        nextLevelLabel = myFont.render("To next level: %(pointsToNextLevel)d" %vars(), 1, (255, 255, 0))
        
        screen.blit(scoreLabel, (10, 20))
        screen.blit(levelLabel, (10, 40))
        screen.blit(nextLevelLabel, (10, 60))
        
        allSprites.draw(screen)
        pygame.display.flip()
        #should prevent writing bug
        screen.blit(background, (0, 0))
    
    #return mouse cursor
    pygame.mouse.set_visible(True) 
    return score

#instuctions screen
def instructions(score):
    insFont = pygame.font.SysFont(None, 50)

    instructions = (
    "Last score: %d" % score,
    "Instructions:  You are a fighter pilot,",
    "combating the enemy.",
    "",
    "Fire on the enemy by pressing the spacebar,",
    "and maneuver using the arrow keys",    
    "You score points by destroying planes",
    "but loose them by letting an enemy escape",
    "",
    "Click to start, escape to quit..."
    )

    insLabels = []    
    for line in instructions:
        tempLabel = insFont.render(line, 1, (255, 255, 0))
        insLabels.append(tempLabel)
 
    keepGoing = True
    clock = pygame.time.Clock()
    pygame.mouse.set_visible(True)
    while keepGoing:
        clock.tick(30)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                keepGoing = False
                donePlaying = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                keepGoing = False
                donePlaying = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    keepGoing = False
                    donePlaying = True

        for i in range(len(insLabels)):
            screen.blit(insLabels[i], (50, 30*i))

        pygame.display.flip()
        
    pygame.mouse.set_visible(True)
    return donePlaying

def main():
    donePlaying = False
    score = 0
    while not donePlaying:
        donePlaying = instructions(score)
        if not donePlaying:
            score = game()
            
if __name__ == "__main__":
    main()
            
