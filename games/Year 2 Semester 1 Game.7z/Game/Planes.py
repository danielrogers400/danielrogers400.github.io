"""
Handles plane objects - they must all be constructed with a reference to the screen object from 
the main module, as it's needed for location calculation
"""

import pygame
import random

class PlayersPlane(pygame.sprite.Sprite):
    """
    Plane used exclusively by the player.
    Has manual movement and fire
    """
    def __init__(self, bulletsArray, screen):
        self.local_screen = screen
        self.bulletsArray = bulletsArray
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("sprites/plane.gif")
        self.rect = self.image.get_rect()
        self.rect.center = (self.local_screen.get_width() / 2, screen.get_height() - 50)
        self.x = screen.get_width() / 2
        self.y = screen.get_height() - 50
        self.moveSpeed = 10
        self._currentBullet = None
        self.startingHealth = 100.0
        self.health = self.startingHealth
        self.healthbar = HealthBar(self, self.local_screen) 
        
    def update(self):
        self.checkKeys()
        self.healthbar.update(self, self.health, self.startingHealth)
        
    def fireBullet(self):
        """
        Finds an available bullet and begins it's fire sequence
        """
        self._currentBullet = self.selectBulletToFire(self.bulletsArray)
        if self._currentBullet != -1: #make sure there's at least 1 bullet available
            self._currentBullet.fire(self.rect.centerx, self.rect.centery - 20, 10)
        
    def checkKeys(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            #the + 30 here and - 30 below give the plane a "half boundary"
            if (self.x > -30):
                self.x = self.x - self.moveSpeed
                self.rect.center = (self.x, self.y)
            else:
                self.x = self.local_screen.get_width()
                self.rect.center = (self.x, self.y)
                
        if keys[pygame.K_RIGHT]:
            if (self.x < self.local_screen.get_width() + 30):
                self.x = self.x + self.moveSpeed
                self.rect.center = (self.x, self.y)
            else:
                self.x = 0
                self.rect.center = (self.x, self.y)
    
    def selectBulletToFire(self, bullets):
        """
        Selects a bullet to fire from the given array, bullets,
        by checking their can_fire property.
        Returns the first available bullet
        Returns -1 if no bullets are available
        """
        for item in bullets:
            if item.can_fire:
                return item
        return -1

class EnemyPlaneBasic(pygame.sprite.Sprite):
    """
    Basic plane used by enemies.
    """
    def __init__(self, screen, scoreObj):
        self.local_screen = screen
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("sprites/enemy_plane.gif")
        self.rect = self.image.get_rect()
        self.x = random.randrange(50, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.speed = 6
        self.startingHealth = 100.0
        self.health = self.startingHealth
        self.healthbar = HealthBar(self, self.local_screen) 
        self.scoreObj = scoreObj
        
    def update(self):   
        if self.scoreObj.currentLevel < 6: #This plane should only appear before level 6
            self.checkBounds()
            self.updatePosition()
            self.healthbar.update(self, self.health, self.startingHealth)
        
    def checkBounds(self):
        screen = self.local_screen
        if self.y > screen.get_height() + 40:
            self.reset()
            if self.scoreObj.CurrentScore >= 50:
                self.scoreObj.CurrentScore -= 50
                self.scoreObj.toNextLevel += 50
                
    def updatePosition(self): 
        self.y += self.speed
        self.rect.center = (self.x, self.y)
                
    def reset(self):        
        self.x = random.randrange(40, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.health = self.startingHealth
        
class EnemyPlaneLevel2(pygame.sprite.Sprite):
    """
    Another plane used by enemies.
    This one flies faster than the previous plane and has more health
    """
    def __init__(self, screen, scoreObj):
        self.local_screen = screen
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("sprites/enemy_plane2.gif")
        self.rect = self.image.get_rect()
        self.x = random.randrange(50, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.speed = 7
        self.startingHealth = 150.0
        self.health = self.startingHealth
        self.healthbar = HealthBar(self, self.local_screen) 
        self.scoreObj = scoreObj
        
    def update(self):    
        if self.scoreObj.currentLevel >= 2: #should only appear after level 2
            self.checkBounds()
            self.updatePosition()
            self.healthbar.update(self, self.health, self.startingHealth)
        
    def checkBounds(self):
        screen = self.local_screen
        if self.y > screen.get_height() + 40:
            self.reset()
            if self.scoreObj.CurrentScore >= 50:
                self.scoreObj.CurrentScore -= 50
                self.scoreObj.toNextLevel += 50
                
    def updatePosition(self): 
        self.y += self.speed
        self.rect.center = (self.x, self.y)
                
    def reset(self):
            self.x = random.randrange(40, self.local_screen.get_width() - 40)
            self.y = -40
            self.rect.center = (self.x, self.y)
            self.health = self.startingHealth
        
class EnemyPlaneLevel3(pygame.sprite.Sprite):
    """
    Advanced plane used by enemies.
    This plane is slow moving, but has lots of health and fires bullets
    """
    def __init__(self, screen, scoreObj, ammoObjectsArray):
        self.local_screen = screen
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("sprites/enemy_plane3.gif")
        self.rect = self.image.get_rect()
        self.x = random.randrange(50, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.speed = 4
        self.startingHealth = 200.0
        self.health = self.startingHealth
        self.healthbar = HealthBar(self, self.local_screen) 
        self.scoreObj = scoreObj
        self.ammoObj = ammoObjectsArray
        self.can_fire = True
        
    def update(self):    
        if self.scoreObj.currentLevel >= 4: 
            self.checkBounds()
            self.updatePosition()
            self.healthbar.update(self, self.health, self.startingHealth)
        
    def checkBounds(self):
        screen = self.local_screen
        if self.y > screen.get_height() + 40:
            self.reset()
            if self.scoreObj.CurrentScore >= 50:
                self.scoreObj.CurrentScore -= 50
                self.scoreObj.toNextLevel += 50
                
    def updatePosition(self): 
        self.y += self.speed
        self.rect.center = (self.x, self.y)
       
        #the plane always fires at a set position, and fires it's bullets in a set pattern
        if self.y > 100 and self.can_fire:
            dirArray = [225, 255, 285, 315]
            #Loop through the ammo array and fire the bullets
            for i in range(4):
                self.ammoObj[i].fire(self.x, self.y, dirArray[i])
            self.can_fire = False
                
    def reset(self):
        self.x = random.randrange(40, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.health = self.startingHealth 
        self.can_fire = True

class EnemyPlaneLevel4(pygame.sprite.Sprite):
    """
    Clone of the firing plane; used in later levels as a replacement for the basic plane
    """
    def __init__(self, screen, scoreObj, ammoObjectsArray):
        self.local_screen = screen
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("sprites/enemy_plane3.gif")
        self.rect = self.image.get_rect()
        self.x = random.randrange(50, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.speed = 4
        self.startingHealth = 200.0
        self.health = self.startingHealth
        self.healthbar = HealthBar(self, self.local_screen) 
        self.scoreObj = scoreObj
        self.ammoObj = ammoObjectsArray
        self.can_fire = True
        
    def update(self):    
        if self.scoreObj.currentLevel >= 6: 
            self.checkBounds()
            self.updatePosition()
            self.healthbar.update(self, self.health, self.startingHealth)
        
    def checkBounds(self):
        screen = self.local_screen
        if self.y > screen.get_height() + 40:
            self.reset()
            if self.scoreObj.CurrentScore >= 50:
                self.scoreObj.CurrentScore -= 50
                self.scoreObj.toNextLevel += 50
                
    def updatePosition(self): 
        self.y += self.speed
        self.rect.center = (self.x, self.y)
       
        if self.y > 100 and self.can_fire:
            dirArray = [225, 255, 285, 315]
            for i in range(4):
                self.ammoObj[i].fire(self.x, self.y, dirArray[i])
            self.can_fire = False
                
    def reset(self):
        self.x = random.randrange(40, self.local_screen.get_width() - 40)
        self.y = -40
        self.rect.center = (self.x, self.y)
        self.health = self.startingHealth 
        self.can_fire = True
        
                
class HealthBar():
    """
    Health bar used by all planes
    """
    def __init__(self, startObj, screen):
        self.screen = screen
        pygame.draw.rect(self.screen, (255, 0, 0), ((startObj.rect.center),(1,1)), 5)
        
    def update(self, startObj, health, startingHealth):
        #find the bottom left point of the plane's rectangle, add 10 to it, and use this as
        #starting point for health bar
        bottomLeftX, bottomLeftY = startObj.rect.bottomleft
        bottomLeftY += 10
        bottomLeftX += 5
        point1 = (bottomLeftX, bottomLeftY)
        healthAsPercentage = ((health/startingHealth) * 100.0)
        point2 = (healthAsPercentage / 2, 6)
        pygame.draw.rect(self.screen, (255, 0, 0), (point1, point2), 5)
        
        
        