import java.util.Scanner;
public class PlayerData
{
	//PlayerData class contains player data and methods to manipulate this data.
	
	//Any player with 2 pieces on any row, column or diagonal could potentially 
	//win in the next move, so this can be used to make the AI act intelligently
	//Player X pieces
	private int Xrow1Pieces;
	private int Xrow2Pieces;
	private int Xrow3Pieces;
	private int Xcol1Pieces;
	private int Xcol2Pieces;
	private int Xcol3Pieces;
	//diag1 starts in the top left hand corner
	private int Xdiag1Pieces;
	//diag2 starts in the bottom left hand corner
	private int Xdiag2Pieces;
	
	//Player O pieces
	private int Orow1Pieces;
	private int Orow2Pieces;
	private int Orow3Pieces;
	private int Ocol1Pieces;
	private int Ocol2Pieces;
	private int Ocol3Pieces;
	//diag1 starts in the top left hand corner
	private int Odiag1Pieces;
	//diag2 starts in the bottom left hand corner
	private int Odiag2Pieces;
	//Array of board positions
	private String[] posArray;
	
	/**
	 * Constructs object with all variables reset
	 */
	public PlayerData()
	{
		Xrow1Pieces = 0;
		Xrow2Pieces = 0;
		Xrow3Pieces = 0;
		Xcol1Pieces = 0;
		Xcol2Pieces = 0;
		Xcol3Pieces = 0;
		Xdiag1Pieces = 0;
		Xdiag2Pieces = 0;
		Orow1Pieces = 0;
		Orow2Pieces = 0;
		Orow3Pieces = 0;
		Ocol1Pieces = 0;
		Ocol2Pieces = 0;
		Ocol3Pieces = 0;
		Odiag1Pieces = 0;
		Odiag2Pieces = 0;
		posArray = new String[] {"-", "-", "-", "-", "-", "-", "-", "-", "-"};
	}
	
	/**
	 * Resets the board
	 */
	public void resetBoard()
	{
		Xrow1Pieces = 0;
		Xrow2Pieces = 0;
		Xrow3Pieces = 0;
		Xcol1Pieces = 0;
		Xcol2Pieces = 0;
		Xcol3Pieces = 0;
		Xdiag1Pieces = 0;
		Xdiag2Pieces = 0;
		Orow1Pieces = 0;
		Orow2Pieces = 0;
		Orow3Pieces = 0;
		Ocol1Pieces = 0;
		Ocol2Pieces = 0;
		Ocol3Pieces = 0;
		Odiag1Pieces = 0;
		Odiag2Pieces = 0;
		posArray = new String[] {"-", "-", "-", "-", "-", "-", "-", "-", "-"};
	}
	
	/**
	 * Checks if the board is full
	 * @return True if board is full, otherwise false
	 */
	public boolean boardIsFull()
	{
		boolean emptySlot = false;
		for (int i = 0; i <= 8; i++)
		{
			if (posArray[i] == "-" )
			{
				emptySlot = true;
			}
		}
		if (emptySlot == true)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	/**
	 * Checks if any counters could win the next round
	 * @param player Player whose counters to check
	 * @return Counter index if can win, -1 if none available, -2 if the game is won
	 */
	public int checkForWinningCounters(String player)
	{
		if (player == "X")
		{
			if(Xrow1Pieces >= 2 && Orow1Pieces == 0)
			{
				if(Xrow1Pieces >= 3)
				{
					return -2;
				}
				return 0;
			}
			if(Xrow2Pieces >= 2 && Orow2Pieces == 0)
			{
				if(Xrow2Pieces >= 3)
				{
					return -2;
				}
				return 1;
			}
			if(Xrow3Pieces >= 2 && Orow3Pieces == 0)
			{
				if(Xrow3Pieces >= 3)
				{
					return -2;
				}
				return 2;
			}
			if(Xcol1Pieces >= 2 && Ocol1Pieces == 0)
			{
				if(Xcol1Pieces >= 3)
				{
					return -2;
				}
				return 3;
			}
			if(Xcol2Pieces >= 2 && Ocol2Pieces == 0)
			{
				if(Xcol2Pieces >= 3)
				{
					return -2;
				}
				return 4;
			}
			if(Xcol3Pieces >= 2 && Ocol3Pieces == 0)
			{
				if(Xcol3Pieces >= 3)
				{
					return -2;
				}
				return 5;
			}
			if(Xdiag1Pieces >= 2 && Odiag1Pieces == 0)
			{
				if(Xdiag1Pieces >= 3)
				{
					return -2;
				}
				return 6;
			}
			if(Xdiag2Pieces >= 2 && Odiag2Pieces == 0)
			{
				if(Xdiag2Pieces >= 3)
				{
					return -2;
				}
				return 7;
			}
		}
		else if (player == "O") 
		{
			if(Orow1Pieces >= 2 && Xrow1Pieces == 0)
			{
				if(Orow1Pieces >= 3)
				{
					return -2;
				}
				return 0;
			}
			if(Orow2Pieces >= 2 && Xrow2Pieces == 0)
			{
				if(Orow2Pieces >= 3)
				{
					return -2;
				}
				return 1;
			}
			if(Orow3Pieces >= 2  && Xrow3Pieces == 0)
			{
				if(Orow3Pieces >= 3)
				{
					return -2;
				}
				return 2;
			}
			if(Ocol1Pieces >= 2 && Xcol1Pieces == 0)
			{
				if(Ocol1Pieces >= 3)
				{
					return -2;
				}
				return 3;
			}
			if(Ocol2Pieces >= 2 && Xcol2Pieces == 0)
			{
				if(Ocol2Pieces >= 3)
				{
					return -2;
				}
				return 4;
			}
			if(Ocol3Pieces >= 2 && Xcol3Pieces == 0)
			{
				if(Ocol3Pieces >= 3)
				{
					return -2;
				}
				return 5;
			}
			if(Odiag1Pieces >= 2 && Xdiag1Pieces == 0)
			{
				if(Odiag1Pieces >= 3)
				{
					return -2;
				}
				return 6;
			}
			if(Odiag2Pieces >= 2  && Xdiag2Pieces == 0)
			{
				if(Odiag2Pieces >= 3)
				{
					return -2;
				}
				return 7;
			}
		}
	return -1;
	}
	

	/**
	 * Gets the player in control of the given position
	 * @param Pos The position to check
	 * @return The owner of the position
	 */
	public String checkPositionOwner(int Position)
	{
		return posArray[Position];
	}

	/**
	 * Finds an empty position on the board
	 * @return The index of the first empty position found, 0 if no position found
	 */
	public int findEmptyPosition()
	{
	
		for (int i = 0; i <= 8; i++)
		{
			if (posArray[i] == "-")
				return i;
		}
		return 0;
	}

	/**
	 * Checks if the game has been won
	 * @return True if the game has been won
	 */
	public boolean gameIsWon()
	{
		if(Xrow1Pieces == 3 || Orow1Pieces == 3 || Xrow2Pieces == 3 || Orow2Pieces == 3 ||
				Xcol2Pieces == 3 || Ocol2Pieces == 3 ||Xcol3Pieces == 3 || Ocol3Pieces == 3 ||
				Xdiag1Pieces == 3 || Odiag1Pieces == 3 ||Xdiag2Pieces == 3 || Odiag2Pieces == 3 ||
				Orow3Pieces == 3 || Xrow3Pieces == 3 ||Ocol1Pieces == 3 || Xcol1Pieces == 3)
		{
			return true;
		}
		else
			return false;
	}

	/**
	 * Gets the array of positions.
	 * @return The array of positions
	 */
	public String[] getPosArray()
	{
		return posArray;
	}

	/**
	 * Gets a winning position based on a counter. If the counter is row1 (0) then it searches for the empty
	 * board position in spaces 0, 1 and 2. If the counter is col1 (3) then is searches for the empty board position
	 * in spaces 0, 3 and 6 etc
	 * @param counter The counter to check in
	 * @return A winning position, if one is available. Otherwise -1.
	 */
	public int getWinningPosition(int counter)
	{
			switch(counter)
			{
				//row1
				case(0):
					if(checkPositionOwner(0) == "-")
						return 0;
					else if(checkPositionOwner(1) == "-")
						return 1;
					else if(checkPositionOwner(2) == "-")
						return 2;
					else return -1;
				//row2
				case(1):
					if(checkPositionOwner(3) == "-")
						return 3;
					else if(checkPositionOwner(4) == "-")
						return 4;
					else if(checkPositionOwner(5) == "-")
						return 5;
					else return -1;
				//row3
				case(2):
					if(checkPositionOwner(6) == "-")
						return 6;
					else if(checkPositionOwner(7) == "-")
						return 7;
					else if(checkPositionOwner(8) == "-")
						return 8;
					else return -1;
				//col1
				case(3):
					if(checkPositionOwner(0) == "-")
						return 0;
					else if(checkPositionOwner(3) == "-")
						return 3;
					else if(checkPositionOwner(6) == "-")
						return 6;
					else return -1;
				//col2
				case(4):
					if(checkPositionOwner(1) == "-")
						return 1;
					else if(checkPositionOwner(4) == "-")
						return 4;
					else if(checkPositionOwner(7) == "-")
						return 7;
					else return -1;
				//col3
				case(5):
					if(checkPositionOwner(2) == "-")
						return 2;
					else if(checkPositionOwner(5) == "-")
						return 5;
					else if(checkPositionOwner(8) == "-")
						return 8;
					else return -1;
				//diag1
				case(6):
					if(checkPositionOwner(0) == "-")
						return 0;
					else if(checkPositionOwner(4) == "-")
						return 4;
					else if(checkPositionOwner(8) == "-")
						return 8;
					else return -1;
				//diag2
				case(7):
					if(checkPositionOwner(2) == "-")
						return 2;
					else if(checkPositionOwner(4) == "-")
						return 4;
					else if(checkPositionOwner(6) == "-")
						return 6;
					else return -1;
				}
			//just to make sure something is always returned
			if (counter > 7)
			{
				return 0;
			}
			else
			{
				return 0;
			}
		}

	/**
	 * gets A random number between the specified values, inclusive.
	 * @param lowest The lowest possible number.
	 * @param highest The highest possible number.
	 * @return A random integer.
	 */
	public int randRange(int lowest, int highest)
	{
		int randomNum = (int) (Math.random() * highest) + lowest;
		return randomNum;
	}
	
	/**
	 * Sets the game mode
	 * @return 0 for computer v computer, 1 for player v computer
	 */
	public int setGameMode()
	{
		Scanner in = new Scanner(System.in);
		int gameMode = 0;
		System.out.println("Set the game mode. 0 for computer vs. computer, 1 for player vs computer: ");
		while (in.hasNext())
		{
			String input = in.next();
			if (input.equalsIgnoreCase("0"))
			{
				gameMode = 0;
				break;
			}
			else if (input.equalsIgnoreCase("1"))
			{
				gameMode = 1;
				break;
			}
			else
			{
				System.out.println("Invalid input. Re-enter your choice: ");
			}
		}
		if (gameMode == 0)
		{
			System.out.println("You have selected computer vs. computer");
		}
		else if (gameMode == 1)
		{
			System.out.println("You have selected player vs. computer");
		}
		return gameMode;
		}

	/**
	 * Sets a position to a player
	 * @param Position The position to change
	 * @param player The player to give the position to
	 */
	public void setPosition(int Position, String player)
	{
		posArray[Position] =  player;
	}
	
	/**
	 * Updates the counters, which track how many pieces each player
	 * contains on each of the rows, columns and diagonals on the board.
	 * @param position The position which the counters should be updated from (0 - 8)
	 * @param player The player who the counters should be updated for.
	 */
	public void updateCounters(int position, String player)
	{
		if (player == "X")
		{
			switch(position)
			{
				case(0): 
					Xrow1Pieces += 1;
					Xcol1Pieces += 1;
					Xdiag1Pieces += 1;	
					break;
				case(1):
					Xrow1Pieces += 1;
					Xcol2Pieces += 1;
					break;
				case(2):
					Xrow1Pieces += 1;
					Xcol3Pieces += 1;
					Xdiag2Pieces += 1;
					break;
				case(3):
					Xrow2Pieces += 1;
					Xcol1Pieces += 1;
					break;
				case(4):
					Xrow2Pieces += 1;
					Xcol2Pieces += 1;
					Xdiag1Pieces += 1;
					Xdiag2Pieces += 1;
					break;
				case(5):
					Xrow2Pieces+= 1;
					Xcol3Pieces += 1;
					break;
				case(6):
					Xrow3Pieces += 1;
					Xcol1Pieces += 1;
					Xdiag2Pieces += 1;
					break;
				case(7):
					Xrow3Pieces += 1;
					Xcol2Pieces += 1;
					break;
				case(8):
					Xrow3Pieces += 1;
					Xcol3Pieces += 1;
					Xdiag1Pieces += 1;
					break;
				}
		}
		else if (player == "O")
		{
			switch(position)
			{
				case(0): 
					Orow1Pieces += 1;
					Ocol1Pieces += 1;
					Odiag1Pieces += 1;	
					break;
				case(1):
					Orow1Pieces += 1;
					Ocol2Pieces += 1;
					break;
				case(2):
					Orow1Pieces += 1;
					Ocol3Pieces += 1;
					Odiag2Pieces += 1;
					break;
				case(3):
					Orow2Pieces += 1;
					Ocol1Pieces += 1;
					break;
				case(4):
					Orow2Pieces += 1;
					Ocol2Pieces += 1;
					Odiag1Pieces += 1;
					Odiag2Pieces += 1;
					break;
				case(5):
					Orow2Pieces+= 1;
					Ocol3Pieces += 1;
					break;
				case(6):
					Orow3Pieces += 1;
					Ocol1Pieces += 1;
					Odiag2Pieces += 1;
					break;
				case(7):
					Orow3Pieces += 1;
					Ocol2Pieces += 1;
					break;
				case(8):
					Orow3Pieces += 1;
					Ocol3Pieces += 1;
					Odiag1Pieces += 1;
					break;
				}
		}
	}
}
