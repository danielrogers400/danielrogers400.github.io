import java.util.Scanner;
public class TicTacToe
{
	static PlayerData PlayerDataObj = new PlayerData();
	public static void main(String[] args) 
	{
		System.out.println("Game positions:");
		drawBoardTemplate();
		
		boolean playAgain = true;
			boolean gameWon = false;
			int gameMode = PlayerDataObj.setGameMode();
			if (gameMode == 0)
			{
				while(!gameWon)
				{
					AIPlayerXTakeTurn();
					if (waitForNextTurn("X") == false)
					{
						gameWon = true;
						break;
					}
					AIPlayerOTakeTurn();
					if (waitForNextTurn("O") == false)
					{
						gameWon = true;
						break;
					}
				}
			}
			else if (gameMode == 1)
			{
				while(!gameWon)
				{
					humanPlayerTakeTurn();
					if (waitForNextTurn("X") == false)
					{
						gameWon = true;
						break;
					}
					AIPlayerOTakeTurn();
					if (waitForNextTurn("O") == false)
					{
						gameWon = true;
						break;
					}
				}
			
		}
	}
	
	/**
	 * Draws the playing board based on the given array of positions
	 * @param PosArray The array of positions to draw the board from
	 */
	public static void drawBoard(String[] PosArray)
	{
		
		System.out.println("*************");
		System.out.printf("* %-2s*", PosArray[0]);
		System.out.printf(" %-2s", PosArray[1]);
		System.out.printf("* %-2s*", PosArray[2]);
		System.out.println();
		System.out.printf("* %-2s*", PosArray[3]);
		System.out.printf(" %-2s", PosArray[4]);
		System.out.printf("* %-2s*", PosArray[5]);
		System.out.println();
		System.out.printf("* %-2s*", PosArray[6]);
		System.out.printf(" %-2s", PosArray[7]);
		System.out.printf("* %-2s*\n", PosArray[8]);
		System.out.println("*************");
	}
	
	/**
	 * Draws a template of the board with the position indexs
	 */
	public static void drawBoardTemplate()
	{
		System.out.println("*************");
		System.out.printf("* %-2s*", 0);
		System.out.printf(" %-2s", 1);
		System.out.printf("* %-2s*", 2);
		System.out.println();
		System.out.printf("* %-2s*", 3);
		System.out.printf(" %-2s", 4);
		System.out.printf("* %-2s*", 5);
		System.out.println();
		System.out.printf("* %-2s*", 6);
		System.out.printf(" %-2s", 7);
		System.out.printf("* %-2s*\n", 8);
		System.out.println("*************");
	}
	
	/**
	 * Takes the turn for the AI X player
	 */
	public static void AIPlayerXTakeTurn()
	{
		//if a winning position is found
		if(PlayerDataObj.checkForWinningCounters("X") != -1)
		{
			int positionToTake = PlayerDataObj.getWinningPosition(PlayerDataObj.checkForWinningCounters("X"));
			if (positionToTake == -1)
			{
				positionToTake = PlayerDataObj.findEmptyPosition();
			}
			PlayerDataObj.setPosition(positionToTake, "X");
			PlayerDataObj.updateCounters(positionToTake, "X");
		}
		//if the other player has got a winning position lined up
		else if (PlayerDataObj.checkForWinningCounters("O") != -1)
		{
			int positionToTake = PlayerDataObj.getWinningPosition(PlayerDataObj.checkForWinningCounters("O"));
			if (positionToTake == -1)
			{
				positionToTake = PlayerDataObj.findEmptyPosition();
			}
			PlayerDataObj.setPosition(positionToTake, "X");
			PlayerDataObj.updateCounters(positionToTake, "X");
		}
		//Otherwise, pick a random spot
		else
		{
			
			int posToTake = PlayerDataObj.randRange(0, 9);
			while(PlayerDataObj.checkPositionOwner(posToTake) != "-" )
			{
				posToTake = PlayerDataObj.randRange(0, 9);
			}
			//set the position, update the counters
			PlayerDataObj.setPosition(posToTake, "X");
			PlayerDataObj.updateCounters(posToTake, "X");
		}
	
	}
	
	/**
	 * Takes the turn for the AI O player
	 */
	public static void AIPlayerOTakeTurn()
	{
		//if a winning position is found
		if(PlayerDataObj.checkForWinningCounters("O") != -1)
		{
			int positionToTake = PlayerDataObj.getWinningPosition(PlayerDataObj.checkForWinningCounters("O"));
			if (positionToTake == -1)
			{
				positionToTake = PlayerDataObj.findEmptyPosition();
			}
			PlayerDataObj.setPosition(positionToTake, "O");
			PlayerDataObj.updateCounters(positionToTake, "O");
		}
		//if the other player has got a winning position lined up
		else if (PlayerDataObj.checkForWinningCounters("X") != -1)
		{
			int positionToTake = PlayerDataObj.getWinningPosition(PlayerDataObj.checkForWinningCounters("X"));
			if (positionToTake == -1)
			{
				positionToTake = PlayerDataObj.findEmptyPosition();
			}
			PlayerDataObj.setPosition(positionToTake, "O");
			PlayerDataObj.updateCounters(positionToTake, "O");
		}
		//Otherwise, pick a random spot
		else
		{
			
			int posToTake = PlayerDataObj.randRange(0, 9);
			while(PlayerDataObj.checkPositionOwner(posToTake) != "-" )
			{
				posToTake = PlayerDataObj.randRange(0, 9);
			}
			//set the position, update the counters
			PlayerDataObj.setPosition(posToTake, "O");
			PlayerDataObj.updateCounters(posToTake, "O");
		}
	}
	
	/**
	 * Ends the game if the board is full, otherwise waits for input to advance to the next turn
	 * @param player the player who has taken his turn
	 * @return false if the game is over, true if it should continue
	 */
	public static boolean waitForNextTurn(String player)
	{
		Scanner in = new Scanner(System.in);
		drawBoard(PlayerDataObj.getPosArray());
		boolean playAgain = false;
		if(PlayerDataObj.gameIsWon())
		{
			System.out.println("Game over!\nPlay Again(y/n)?");
			
			//while (in.hasNext())
			//{
				String input = in.next();
				if (input.equalsIgnoreCase("y"))
				{
					playAgain = true;
				}
			//}
			if( playAgain)
			{
				PlayerDataObj.resetBoard();
				return true;
			}
			else
			{
				return false;		
			}
		}
		else if (PlayerDataObj.boardIsFull())
		{
			System.out.println("Game over!\nPlay Again(y/n)?");
			//while (in.hasNext())
			//{
				String input = in.next();
				if (input.equalsIgnoreCase("y"))
				{
					playAgain = true;
				}
			//}
			if( playAgain)
			{
				PlayerDataObj.resetBoard();
				return true;
			}
			else
			{
				return false;		
			}
		}
		else
		{
			System.out.println("Player " +  player + " has taken his move, press any key to continue: ");
			while(!in.hasNext())
			{
				
			}
			return true;
		}
		
	}

	/**
	 * Lets the human player take his/her turn (as player X)
	 */
	public static void humanPlayerTakeTurn()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the position you want to take (0 - 8)\n");
		
		
		while (in.hasNext())
		{
			String input = in.next();
			if (input.equalsIgnoreCase("0") && PlayerDataObj.checkPositionOwner(0) == "-")
			{
				PlayerDataObj.setPosition(0, "X");
				PlayerDataObj.updateCounters(0, "X");
				break;
			}
			else if (input.equalsIgnoreCase("1") && PlayerDataObj.checkPositionOwner(1) == "-")
			{
				PlayerDataObj.setPosition(1, "X");
				PlayerDataObj.updateCounters(1, "X");
				break;
			}
			else if (input.equalsIgnoreCase("2") && PlayerDataObj.checkPositionOwner(2) == "-")
			{
				PlayerDataObj.setPosition(2, "X");
				PlayerDataObj.updateCounters(2, "X");
				break;
			}
			else if (input.equalsIgnoreCase("3") && PlayerDataObj.checkPositionOwner(3) == "-")
			{
				PlayerDataObj.setPosition(3, "X");
				PlayerDataObj.updateCounters(3, "X");
				break;
			}
			else if (input.equalsIgnoreCase("4") && PlayerDataObj.checkPositionOwner(4) == "-")
			{
				PlayerDataObj.setPosition(4, "X");
				PlayerDataObj.updateCounters(4, "X");
				break;
			}
			else if (input.equalsIgnoreCase("5") && PlayerDataObj.checkPositionOwner(5) == "-")
			{
				PlayerDataObj.setPosition(5, "X");
				PlayerDataObj.updateCounters(5, "X");
				break;
			}
			else if (input.equalsIgnoreCase("6") && PlayerDataObj.checkPositionOwner(6) == "-")
			{
				PlayerDataObj.setPosition(6, "X");
				PlayerDataObj.updateCounters(6, "X");
				break;
			}
			else if (input.equalsIgnoreCase("7") && PlayerDataObj.checkPositionOwner(7) == "-")
			{
				PlayerDataObj.setPosition(7, "X");
				PlayerDataObj.updateCounters(7, "X");
				break;
			}
			else if (input.equalsIgnoreCase("8") && PlayerDataObj.checkPositionOwner(8) == "-")
			{
				PlayerDataObj.setPosition(8, "X");
				PlayerDataObj.updateCounters(8, "X");
				break;
			}
			else
			{
				System.out.println("Invalid input: Either the position is taken or you have entered an incorrect character. Re-enter your choice (0 - 8): ");
			}
		}
	}
	
	public static boolean playAgain()
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Do you want to play again? (y/n)");
		String input = in.next();
		if (input.equalsIgnoreCase("y"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
