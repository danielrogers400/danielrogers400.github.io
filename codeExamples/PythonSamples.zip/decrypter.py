#File: decrypter.py
#This file handles the basic UI utilised by the program

from string import lowercase, uppercase
from Resources.frequency_analysis import * 
from Resources.ciphers  import *



#frequency_count("The quick brown fox jumps over the lazy dog")
#print swap_occurence("HELLo", "L", "P")

running = True
cipherText = raw_input("Enter the enciphered string: ")
originalText = cipherText
while (running):
    
    option = raw_input("Press 1 to analyse text.\nPress 2 to swap letters." +
                   "\nPress 3 to print text.\nPress 4 to reset text to original value & print." +
                   "\nPress 5 for a Caesar crack.\nPress 6 for a number decipher." +
                   "\nPress 7 for a Harha Tana decipher.\nPress 8 for an Atbash decipher." +
                   "\nPress 9 to enter a new encrypted message.\n" +
                   "Press 10 to display all Caesar and atbash cipher combinations.\n" +
                   "Press 11 to display all Caesar and Harha Tana combinations.\n" +
                   "Press 12 to display all Caesar, Atbash and HT combos.\n" +
                   "Press 13 to try combinations of all 3 ciphers.\n" +
                   "Press q to quit.\nInput:")
    if option == "1":
        analyse_frequency(cipherText, True)
    elif option == "2":
        cipherText = swap_occurence(cipherText)
    elif option == "3":
        print cipherText + "\n"
    elif option == "4":
        print "\n><><><><><><\nYou have reset the text to the following:\n><><><><><><\n"
        cipherText = originalText
        print cipherText + "\n><><><><><><\n"
    elif option == "5":
        print_caesar_crack(cipherText)
    elif option == "6":
        print number_decipher(cipherText) + "\n"
    elif option == "7":
        print harha_tana_cipher(cipherText)
    elif option == "8":
        print atbash_cipher(cipherText)
    elif option == "9":
        originalText = raw_input("Enter your new message: ")
        cipherText = originalText
    elif option == "10":
        print_all_caesar_and_atbash_combos(cipherText)
    elif option == "11":
        print_all_caesar_and_ht_combos(cipherText)
    elif option == "12":
        print_all_caesar_HT_Atbash_combos(cipherText)
    elif option == "13":
        try_all_3_ciphers(cipherText)
    elif option == "q" or option =="Q":
        break
            
        

