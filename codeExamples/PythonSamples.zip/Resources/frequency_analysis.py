#File frequency_analysis.py

from string import *

#Improves upon the old frequency analysis:
    #Now displays letter and letter count side-by-side
    #Has bool toggle to display frequency list is descending order
def analyse_frequency(cipherText, displayDescending):

    #Declare the two arrays - the one that counts all the letters, and the one
    #that will be used to store the data in an ordered fashion
    letter_count_list = [0] * 26
    ordered_list = [0] * 26

    for i in range(26):
        #use 2-d array to display letter and count information neatly
        letter_count_list[i] = [uppercase[i], 0]
        ordered_list[i] = [uppercase[i], 0]

    #Now loop through the input text and note the amount of occurences
    #of each letter
    for char in cipherText.upper():
        if char.isupper():
            letter_count_list[uppercase.index(char)][1] += 1


    #Variable used to get the largest number
    first_maximum = 0
    #Variable used to get the letter corresponding to the largest number
    letter_at_firstMax = ""

    for index in range(26):
        if letter_count_list[index][1] > first_maximum:
            first_maximum = letter_count_list[index][1]
            letter_at_firstMax = letter_count_list[index][0]




    #Double-loop through the input text. Find a the largest number which is smallest that
    # the previously largest number, and add it onto the ordered array

    previous_maximum = first_maximum
    maximum = 0
    #Add the previously found maximum into the first element
    ordered_list[0] = [letter_at_firstMax, first_maximum]

    for i in range(1, 26):
        for ii in range(26):
            if letter_count_list[ii][1] > maximum and letter_count_list[ii][1] < previous_maximum:
                maximum = letter_count_list[ii][1]
                letter_index = letter_count_list[ii][0]
        ordered_list[i][1] = maximum
        ordered_list[i][0] = letter_index
        previous_maximum = maximum
        maximum = 0
        
    for index in range(26):
        if displayDescending:
            print ordered_list[index][0], ordered_list[index][1]
        elif not displayDescending:
            print letter_count_list[index][0], letter_count_list[index][1]

            


