# File: ciphers.py
#This file contains all of the ciphering algorithms used by the program

from string import lowercase, uppercase

def number_cipher(plaintext):
   for character in plaintext.lower():
      if not character.islower():
         print character,
      else:
         print lowercase.index(character),

def caesar_cipher(plaintext, shift):
   ciphertext = ''
   for character in plaintext.lower():
      if not character.islower():
         ciphertext += character
      else:
         number = lowercase.index(character)
         new_number = (number + shift) % 26
         ciphertext += uppercase[new_number]
   return ciphertext

def caesar_decipher(ciphertext, shift):
   plaintext = ''
   for character in ciphertext.upper():
      if not character.isupper():
         plaintext += character
      else:
         number = uppercase.index(character)
         new_number = (number - shift) % 26
         plaintext += lowercase[new_number]
   return plaintext


def print_caesar_crack(ciphertext):
   for shift in range(1, 26):
      print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", caesar_decipher(ciphertext, shift)
      stop = raw_input("Do you want to continue attempting to decrypt?(y/n) Select n to save this decrypted message:\n")
      if not stop == 'y':
         return caesar_decipher(ciphertext, shift)
      
def print_specifc_caesar_crack(ciphertext, shiftKey):
   print "><><><><><><\nShift key: ", shiftKey, "\n><><><><><><\n", caesar_decipher(ciphertext, shiftKey)
   stop = raw_input("Do you want to continue attempting to decrypt?(y/n) Select n to save this decrypted message:\n")
   return caesar_decipher(ciphertext, shiftKey)

def print_all_caesar_and_atbash_combos(ciphertext):
      for shift in range(1, 26):
         print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", atbash_cipher(caesar_decipher(ciphertext, shift))
      return atbash_cipher(caesar_decipher(ciphertext, shift))
   
def print_all_caesar_and_ht_combos(ciphertext):
      for shift in range(1, 26):
         #print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", harha_tana_cipher(caesar_decipher(ciphertext, shift))
         print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", caesar_decipher(harha_tana_cipher(ciphertext), shift)
      #return harha_tana_cipher(caesar_decipher(ciphertext, shift))

def print_all_caesar_HT_Atbash_combos(ciphertext):
    for shift in range(1, 26):
       #print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", harha_tana_cipher(caesar_decipher(ciphertext, shift))
       print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", caesar_decipher(harha_tana_cipher(atbash_cipher(ciphertext)), shift)

def try_all_3_ciphers(cipherText):
   keepGoing = "y"
   while keepGoing == "y":
      #Type 1
      print "Type 1 - Caesar, Harha Tana, Atbash"
      for shift in range(1, 26):
         print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", caesar_decipher(harha_tana_cipher(atbash_cipher(cipherText)), shift)
      keepGoing = raw_input("Try another type? (y/n)")
      if not keepGoing == "y":
         break
      #Type 2
      print "Type 2 - Harha Tana, Atbash, Caesar"
      for shift in range(1, 26):
         print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", harha_tana_cipher(atbash_cipher(caesar_decipher(cipherText, shift)))
      keepGoing = raw_input("Try another type? (y/n)")
      if not keepGoing == "y":
         break
      #Type 3
      print "Type 3 - Caesar, Atbash, Harha Tana"
      for shift in range(1, 26):
         print "><><><><><><\nShift key: ", shift, "\n><><><><><><\n", caesar_decipher(atbash_cipher(harha_tana_decipher(cipherText)), shift)
      keepGoing = raw_input("Try another type? (y/n)")
      if not keepGoing == "y":
         break


def number_decipher(ciphertext):
   plaintext = ''
   for character in ciphertext.split():
      if character.isdigit():
         #parse char to int
         number = int(character)
         plaintext += lowercase[number]
      else:
         plaintext += character
   return plaintext

#Harha Tana
#Two-way cipher
#A = B C =D E = F etc
def harha_tana_cipher(plaintext):
    #plaintext = raw_input("Enter the message to be enciphered: ")
    cipherText = ""
    #convert plaintext to lowercase
    for char in plaintext.lower():
        if not char.islower():
            cipherText += char
        else:
            #avoid zero-division, as 'A' has index of 0
            number = lowercase.index(char) + 1
            if number % 2 == 0:
                newNumber = number - 1
            else:
                newNumber = number + 1
            #subtract 1 to get correct uppercase index
            cipherText += uppercase[newNumber - 1]
    #print cipherText,
    return cipherText

#Atbash Cipher
#Swaps the alphabet A = Z, B = Y etc
def atbash_cipher(plaintext):
    #plaintext = raw_input("Enter the message to be enciphered: ")
    cipherText = ""
    #convert plaintext to lowercase
    for char in plaintext.lower():
        if not char.islower():
            cipherText += char
        else:
            number = lowercase.index(char)
            newNumber = (25 - number) 
            cipherText += uppercase[newNumber]
    #print cipherText,
    return cipherText

#swaps every occurence of a letter in a string with another letter
    #oldChar - letter to replace
    #newChar - letter to insert
def swap_occurence(string):
    firstChar = raw_input("Enter the first char to swap: ").upper()
    secondChar = raw_input("Enter the second char to swap: ").upper()
    newString = ""
    for char in string.upper():
       if char.isupper() and char == firstChar:
            newString += secondChar
       elif char.isupper() and char == secondChar:
            newString += firstChar
       else:
            newString += char
    return newString
