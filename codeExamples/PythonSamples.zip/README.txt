Click on the file dectypter.py to run the program. 
Requires python 2.6 to run