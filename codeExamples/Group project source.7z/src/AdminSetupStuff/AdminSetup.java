package AdminSetupStuff;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import common.CinemaMethods;
import common.CinemaSystemException;
import common.DatabaseConnector;
import common.Menu;

/**
 * 
 * @author Daniel
 * This class contains the admin setup menus. 
 *
 */
public class AdminSetup 
{	
	private Menu mainMenu;
	private Menu addRemoveScreens;
	private Menu addRemoveTimeSlots;
	private Menu addRemoveFilms;
	private Menu currentmenu;
	private Menu databaseOptions;
	private Scanner in;
	private DatabaseConnector dbc;


	/**
	 *  Creates a new object of type AdminSetup, initialises it's menus and connects to the database
	 * @param in Scanner, input stream
	 * @throws CinemaSystemException If the database cannot be found or connected to
	 */
	public AdminSetup (Scanner in)
	{
		this.in = in;
	}


	/**
	 * This method runs the setup menus. When the user has decided to quit, it also closes
	 * the database connection
	 * @param password The password to check against when entering the menu system
	 */
	public void adminSetupMain(String password, String dbName)
	{
		dbc = new DatabaseConnector(dbName);
		if(dbc.connect())
		{
			this.dbc.setCurrentDatabase();
			initialiseMenus();
		}
		else
		{
			dbc.disconnect();
			System.out.println("Could not connect to the database");
			return;
		}

		startMenuSystem();
		this.dbc.disconnect();
	}

	/**
	 * Starts the menus system. Will end when the user has specified to return to the central menu
	 */
	public void startMenuSystem()
	{			
		//if the user doesn't enter a correct password, go back to the main menu
		//otherwise, carry on
		if(!CinemaMethods.checkPassword("Now in Admin setup. Enter Admin password:", in, dbc.getPassword()))
		{
			return;
		}
		//The next menu to navigate to
		Menu nextMenu = mainMenu;
		Menu currentMenu = mainMenu;
		while (true)
		{
			//Print the title of the current menu
			currentMenu.printTitle();
			nextMenu = currentMenu.getNextMenu(in);

			//if the user has selected to exit this menu system, nextMenu will return null
			if (nextMenu == null)
				break;

			currentMenu = nextMenu;
		}
	}

	/**
	 * Handles the add/remove screen menu
	 */
	public Menu addRemoveScreens()
	{
		//find out what the user wants to do
		int input = CinemaMethods.getIntFromUser("Press 0 to add screens, 1 to remove screens, any other numerical input to quit to Admin Setup Root menu", in);
		//id used when assigning time slots
		int timeSlotID = 0;
		//each screen can only have 3 time slots
		int[] timeSlotIdArray = new int[3];
		ArrayList<Db_Screen> screensList = new ArrayList<Db_Screen>();

		//user has selected to add screens
		if(input == 0)
		{
			//At all stages the user will have an option to quit, so it must be dealt with
			input = CinemaMethods.getIntFromUser("Now in add screen menu.\nEnter the amount of screens you would like to add (integer input), or -1 to quit and discard data", in);
			if (input == -1)
			{
				return mainMenu;
			}	
			else
			{
				//Loop for as many screens as the user wants to add
				for(int e =1; e <= input; e++)
				{
					System.out.println("Adding screen: " + e + "/" + input);
					//for each screen, loop through the time slots and find out the ID to assign to each
					for (int i = 0; i<3; i ++)
					{
						timeSlotID = CinemaMethods.getIntFromUser("Enter the timeslot ID to use in timeslot " + i + "(integer input), -1 to quit and discard changes", in);

						if (timeSlotID == -1)
						{
							return mainMenu;
						}		
						else
						{
							timeSlotIdArray[i] = timeSlotID;
						}
					}
					//Add all of these screen objects to an ArrayList, don't write to database until the last possible moment
					Db_Screen s = new Db_Screen(timeSlotIdArray[0], timeSlotIdArray[1], timeSlotIdArray[2]);
					screensList.add(s);
					//System.out.println("Added screen to list");
				}
				//At this stage all of the info is gathered, so work on the database
				dbc.addScreens(screensList);
				return mainMenu;
			}
		}
		//user has selected to remove screens
		else if (input == 1)
		{
			while (true)
			{
				int sID = 0;
				input = CinemaMethods.getIntFromUser("Now in remove screen menu.\nEnter the id of the next screen you'd like to remove (integer input), or -1 to finish", in);
				if (input == -1)
				{
					return mainMenu;
				}	
				else
				{
					sID = input;
					//Give the user an "are you sure" / chance to abort
					input = CinemaMethods.getIntFromUser("About to remove screen: " + sID + "\nPress 0 to confirm, -1 to quit. This action cannot be undone", in);
					if (input == -1)
					{
						return mainMenu;
					}	
					else
					{
						//delete the screen
						dbc.removeScreen(sID);
						System.out.println("Any existing screen with ID of " + sID + " deleted");
					}
				}
			}
		}
		//user has selected to quit, so go directly back to main menu
		else
		{
			return mainMenu;
		}

	}

	/**
	 * Handles the add/remove timeslot menu
	 */
	public Menu addRemoveTimeSlots()
	{
		//The amount of slots the user wants to add
		int slotsToAdd = 0;
		//the film associated with the current timeslot
		int filmID = 0;
		//the total amount of seats available in the screen at this time
		int totalSeats = 0;
		//The time that the film in this slot starts at
		String startTime = "";

		ArrayList<Db_TimeSlot> slotsList = new ArrayList<Db_TimeSlot>();

		//find out what the user wants to do
		int input = CinemaMethods.getIntFromUser("Press 0 to add timeSlots, 1 to remove timeSlots, any other numerical input to quit to Admin Setup Root menu", in);
		//user has selected to add slots
		if(input == 0)
		{
			//At all stages the user will have an option to quit, so it must be dealt with
			input = CinemaMethods.getIntFromUser("Now in add time slot menu.\nEnter the amount of slots you would like to add (integer input), or -1 to quit and discard data", in);
			if (input == -1)
			{
				return mainMenu;
			}	
			else
			{
				slotsToAdd = input;
				//get the info for each time slot
				for (int i = 1; i <= slotsToAdd; i ++)
				{
					System.out.println("Adding slot " + i + " of " + slotsToAdd);
					filmID = CinemaMethods.getIntFromUser("Enter the film ID to use in timeslot " + i + " (integer input), -1 to quit and discard changes", in);
					if (filmID == -1)
					{
						return mainMenu;
					}

					totalSeats = CinemaMethods.getIntFromUser("Enter the maximum seats to use in timeslot " + i + " (integer input), -1 to quit and discard changes", in);
					if (totalSeats == -1)
					{
						return mainMenu;
					}	
					startTime = CinemaMethods.getStringFromUser("Enter the time that this film will start at (String input, max 5 characters)", in, 5);
					if (startTime.equals("-1"))
					{
						return mainMenu;
					}
					slotsList.add(new Db_TimeSlot(filmID, totalSeats, startTime));
				}
				//At this stage all of the info is gathered, so work on the database
				System.out.println("Adding slots to database");
				dbc.addTimeSlots(slotsList);
			}
			//leave this here to make sure it returns correctly
			return mainMenu;
		}
		//user has selected to remove time slots
		else if (input == 1)
		{
			while(true)
			{
				int fID = 0;
				input = CinemaMethods.getIntFromUser("Now in remove time slot menu.\nEnter the id of the next time slot you'd like to remove, or -1 to finish", in);
				if (input == -1)
				{
					return mainMenu;
				}	
				else
				{
					fID = input;
					//Give the user an "are you sure" / chance to abort

					//Would be a good idea to allow the user to build java objects from the database, so that
					//the film name could be shown here, rather than just the ID
					input = CinemaMethods.getIntFromUser("About to remove timeSlot: " + fID + "\nPress 0 to confirm, -1 to quit. This action cannot be undone", in);
					if (input == -1)
					{
						return mainMenu;
					}	
					else
					{
						//delete the slot
						dbc.removeTimeSlot(fID);
						System.out.println("Any existing time slot with ID of " + fID + " deleted");
					}
				}
			}
		}
		//user has selected to quit, so go directly back to main menu
		else
		{
			return mainMenu;
		}
	}


	/**
	 * Handles the add/remove films menu
	 */
	public Menu addRemoveFilms()
	{
		//The amount of films the user wants to add
		int filmsToAdd = 0;
		//the screen associated with the current film
		int screenID = 0;
		//the length of the film (in minutes)
		int filmLength = 0;
		//The name of the film
		String filmName = "";

		ArrayList<Db_Film> filmsList = new ArrayList<Db_Film>();

		//find out what the user wants to do
		int input = CinemaMethods.getIntFromUser("Press 0 to add films, 1 to remove films, any other numerical input to quit to Admin Setup Root menu", in);
		//user has selected to add films
		if(input == 0)
		{
			//At all stages the user will have an option to quit, so it must be dealt with
			input = CinemaMethods.getIntFromUser("Now in add film menu.\nEnter the amount of films you would like to add (integer input), or -1 to quit and discard data", in);
			if (input == -1)
			{
				return mainMenu;
			}	
			else
			{
				filmsToAdd = input;
				//get the info for each time slot
				for (int i = 1; i <= filmsToAdd; i ++)
				{
					System.out.println("Adding film " + i + " of " + filmsToAdd);
					screenID = CinemaMethods.getIntFromUser("Enter the ID of the screen that this film (" + i + " of " + filmsToAdd + ") is showing in  (integer input), -1 to quit and discard changes", in);
					if (screenID == -1)
					{
						return mainMenu;
					}

					filmLength = CinemaMethods.getIntFromUser("Enter the length of the film in minutes (integer input), -1 to quit and discard changes", in);
					if (filmLength == -1)
					{
						return mainMenu;
					}	
					filmName = CinemaMethods.getStringFromUser("Enter the name of this film (String input, max 40 characters)", in, 40);
					if (filmName.equals("-1"))
					{
						return mainMenu;
					}
					filmsList.add(new Db_Film(filmLength, filmName));
				}
				//At this stage all of the info is gathered, so work on the database
				System.out.println("Adding films to database");
				dbc.addFilms(filmsList);
			}
			//leave this here to make sure it returns correctly
			return mainMenu;
		}
		//user has selected to remove films
		else if (input == 1)
		{
			while(true)
			{
				int fID = 0;
				input = CinemaMethods.getIntFromUser("Now in remove film menu.\nEnter the id of the next film you'd like to remove, or -1 to finish", in);
				if (input == -1)
				{
					return mainMenu;
				}	
				else
				{
					fID = input;
					//Give the user an "are you sure" / chance to abort
					input = CinemaMethods.getIntFromUser("About to remove film: " + fID + "\nPress 0 to confirm, -1 to quit. This action cannot be undone", in);
					if (input == -1)
					{
						return mainMenu;
					}	
					else
					{
						//delete the screen
						dbc.removeFilm(fID);
						System.out.println("Any existing film with ID of " + fID + " deleted");
					}
				}
			}
		}
		//user has selected to quit, so go directly back to main menu
		else
		{
			return mainMenu;
		}
	}


	/**
	 * Handles the database options menu. From here, users can delete or rest the database
	 * @return null, regardless of success (sends the user back to the central menu system)
	 */
	public Menu databaseOptions()
	{		
		//find out what the user wants to do
		int input = CinemaMethods.getIntFromUser("0 - Reset the database\n1 - Wipe database from disk\n3 - Change database password\nAny other numerical input - quit. After quitting you will be returned to the main menu.", in);
		if(input == 0)
		{
			this.dbc.resetDatabase();
		}
		else if (input == 1)
		{
			this.dbc.wipeDatabase();
		}
		else if (input == 2)
		{
			String str = CinemaMethods.getStringFromUser("Enter new password:", in, 10);
			dbc.setPassword(str);
			System.out.println("\t...Password set to " + dbc.getPassword());
		}
		//After this is completed, the user will need to reconnect to the database. return null here to get
		//back to the main menu and force a reconnect.
		return null;
	}

	/**
	 * Initialises all menus to be used. Must be called before any menus can be used
	 */
	public void initialiseMenus()
	{
		mainMenu = new Menu("Admin Setup Root Menu")
		{
			public Menu getNextMenu(Scanner in) 
			{
				int adminSetupOption = CinemaMethods.getIntFromUser("1  - Add/Remove Screens\n2  - Add/Remove Time Slots\n3  - Add/Remove Films\n4  - Other database options\n5  - Display database\n-1 - Return to main menu", in);
				if (adminSetupOption == 1)
				{
					return addRemoveScreens;
				}
				else if(adminSetupOption == 2)
				{
					System.out.println("Add/Remove Time Slots");
					return addRemoveTimeSlots;
				}
				else if(adminSetupOption == 3)
				{
					System.out.println("Add/Remove Films");
					return addRemoveFilms;
				}
				else if(adminSetupOption == 4)
				{
					return databaseOptions;
				}
				else if(adminSetupOption == 5)
				{
					try 
					{
						System.out.println("\nScreen table:");
						dbc.displayScreenTable();
						System.out.println("\nFilm table:");
						dbc.displayFilmTable();
						System.out.println("\nTime slot table:");
						dbc.displayTimeSlotTable();
					} catch (SQLException e) 
					{
						System.out.println("Error printing db info");
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
					return this;
				}
				else if(adminSetupOption == -1)
				{
					//the user has selected to quit, so  go back to the root menu
					return null;
				}
				else
				{
					System.out.println("Invalid Input. Returning to main menu");
					return mainMenu;
				}
			}
		};

		addRemoveScreens = new Menu("Add or Remove screens")
		{
			public Menu getNextMenu(Scanner in) 
			{
				return addRemoveScreens();
			}
		}; 

		addRemoveTimeSlots = new Menu("Add or Remove time slots")
		{
			public Menu getNextMenu(Scanner in) 
			{
				return addRemoveTimeSlots();
			}
		}; 

		addRemoveFilms = new Menu("Add or Remove films")
		{
			public Menu getNextMenu(Scanner in) 
			{
				return addRemoveFilms();
			}
		}; 

		databaseOptions = new Menu("Database control options")
		{
			public Menu getNextMenu(Scanner in)
			{
				return databaseOptions();
			}
		};

	}
}