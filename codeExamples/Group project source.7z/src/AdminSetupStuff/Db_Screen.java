package AdminSetupStuff;

/**
 * Represents a database screen
 * @author Daniel Rogers - A00184128
 *
 */
public class Db_Screen 
{
	private int timeSlot1ID;
	private int timeSlot2ID;
	private int timeSlot3ID;
	private int id;
	
	public Db_Screen()
	{
		this.timeSlot1ID = 0;
		this.timeSlot2ID = 0;
		this.timeSlot3ID = 0;
		this.id = 0;
	}
	
	public Db_Screen(int timeSlot1ID, int timeSlot2ID,int timeSlot3ID)
	{
		this.timeSlot1ID = timeSlot1ID;
		this.timeSlot2ID = timeSlot2ID;
		this.timeSlot3ID = timeSlot3ID;
	}

	
	/**
	 * SHOULD ONLY BE USED FOR INPUTTING DATA TO SQL, ALWAYS SETS THIS ID TO NULL (SQL AUTO-INCREMENTS)
	 */
	public String toString()
	{
		return "null, " + timeSlot1ID + ", " + timeSlot2ID + ", " + timeSlot3ID;
	}
	
	/*
	 * Getters and setters
	 */
	
	public void setID(int id)
	{
		this.id = id;
	}
	
	public int getID()
	{
		return this.id;
	}
	
	public void setTimeSlot1ID(int id)
	{
		this.timeSlot1ID = id;
	}
	
	public int getTimeSlot1ID()
	{
		return this.timeSlot1ID;
	}
	
	public void setTimeSlot2ID(int id)
	{
		this.timeSlot2ID = id;
	}
	
	public int getTimeSlot2ID()
	{
		return this.timeSlot2ID;
	}
	
	public void setTimeSlot3ID(int id)
	{
		this.timeSlot3ID = id;
	}
	
	public int getTimeSlot3ID()
	{
		return this.timeSlot3ID;
	}
}
