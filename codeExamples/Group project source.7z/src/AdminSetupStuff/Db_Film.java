package AdminSetupStuff;

public class Db_Film 
{
	//the id of this film
	private int id;
	private String filmName;
	//The length of the film, in minutes
	private int lengthOfFilm;
	
	public Db_Film()
	{
		this.id = 0;
		this.filmName = "";
		this.lengthOfFilm = 0;
	}
	
	public Db_Film(int lengthOfFilm, String name)
	{
		this.lengthOfFilm = lengthOfFilm;
		this.filmName = name;
	}
	
	/**
	 * SHOULD ONLY BE USED FOR INPUTTING DATA TO SQL, ALWAYS SETS THIS ID TO NULL (SQL AUTO-INCREMENTS)
	 */
	public String toString()
	{
		return "null, \"" + filmName + "\", " + lengthOfFilm;
	}
	
	/*
	 * Getters and setters
	 */
	public void setID(int id)
	{
		this.id = id;
	}
	
	public int getID()
	{
		return this.id;
	}
	
	public void setFilmName(String name)
	{
		this.filmName = name;
	}
	
	public String getFilmName()
	{
		return this.filmName;
	}
	
	public void setLengthOfFilm(int length)
	{
		this.lengthOfFilm = length;
	}
	
	public int getLengthOfFilm()
	{
		return this.lengthOfFilm;
	}
	
}
