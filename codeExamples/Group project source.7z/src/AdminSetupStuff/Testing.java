package AdminSetupStuff;

import java.util.Scanner;

public class Testing 
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		System.out.printf("%-7s%-30s%-6s", "Film ID ", "Film Name", "Length\n");
		System.out.printf("%-7s%-30s%-6s", "Film ID ", "Film Name", "Length\n");
	}
	
	public static String getStringFromUser(String title, Scanner input)
	{
		//print info to user
		System.out.println(title);
		while(true)
		{
			//get input from user
			if(input.hasNextLine())
			{
				return input.nextLine();
			}
			else
			//else if the user has entered invalid input
			{
				//clear the scanner
				input.nextLine();
				//check if the user wants to keep going or exit the program. If the user aborts, return -1
				if(checkInput("Invalid Input. 0 - Try again, 1 - quit", "1", input))
				{
					return "-1";
				}
				//The user has opted to try again, so reprint the question
				System.out.println(title);
			}
		}
	}
	
	public static boolean checkInput(String msg, String checkMsg, Scanner input)
	{
		System.out.println(msg);
		if (input.next().equals(checkMsg))
		{
			return true;
		}
		return false;
	}
}
