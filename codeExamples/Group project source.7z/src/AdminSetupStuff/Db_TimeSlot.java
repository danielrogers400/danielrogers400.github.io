package AdminSetupStuff;
/**
 * Represents a database time slot
 * @author Daniel Rogers - A00184128
 *
 */
public class Db_TimeSlot 
{
	//the id of this timeslot
	private int id;
	//the id of the film to be shown at this timeslot
	private int film_ID;
	//currently free seats in this timeslot
	private int freeSeats;
	private int bookedSeats;
	//string representing the time at which the film starts (24h format)
	private String startTime;
	
	public Db_TimeSlot(int film_ID, int totalSeats, String startTime)
	{
		this.film_ID = film_ID;
		this.freeSeats = totalSeats;
		this.bookedSeats = 0;
		this.startTime = startTime;
	}
	
	public Db_TimeSlot()
	{
		this.film_ID = 0;
		this.freeSeats = 0;
		this.bookedSeats = 0;
		this.startTime = "";
	}
	
	/*
	 * Getters and setters
	 */
	
	public void setID(int id)
	{
		this.id = id;
	}
	
	public int getID()
	{
		return this.id;
	}
	
	public void setFilmID(int id)
	{
		this.film_ID = id;
	}
	
	public int getFilmID()
	{
		return this.film_ID;
	}
	
	public void setFreeSeats(int seats)
	{
		this.freeSeats = seats;
	}
	
	public int getFreeSeats()
	{
		return this.freeSeats;
	}
	
	public void setBookedSeats(int seats)
	{
		this.bookedSeats = seats;
	}
	
	public int getBookedSeats()
	{
		return this.bookedSeats;
	}
	
	public void setStartTime(String time)
	{
		this.startTime = time;
	}
	
	public String getStartTime()
	{
		return this.startTime;
	}
	
	/**
	 * SHOULD ONLY BE USED FOR INPUTTING DATA TO SQL, ALWAYS SETS THIS ID TO NULL
	 */
	public String toString()
	{
		return "null, " + film_ID + ", " + freeSeats + ", " + bookedSeats + ", \"" + startTime + "\"";
	}
}
