package common;

public class CinemaSystemException extends Exception 
{
	private String message;
	
	public CinemaSystemException(String msg)
	{
		this.message = msg;
	}
}
