package common;
import java.util.Scanner;

/**
 * Provides common methods for use in the cinema system
 * @author Everyone
 *	
 */
public class CinemaMethods 
{
	/**
	 * Ask the user for integer input
	 * @param title String, the message to print to the console asking the user for input
	 * @param input Scanner, the input stream
	 * @return A positive number from the user, or -1 if the user has selected the quit option. 
	 * Note that this method does not handle quit  option functionality; it simply informs the 
	 * caller that the user has selected to quit. 
	 * The caller must decide what to do with this information e.g abort the program
	 * altogether, or return to a previous menu
	 * @author A00184128 - Daniel Rogers
	 */
	public static int getIntFromUser(String title, Scanner input)
	{
		//print info to user
		System.out.println(title);
		while(true)
		{
			//get input from user
			//if the input has an int, return it
			if(input.hasNextInt())
			{
				return input.nextInt();
			}
			else
			//else if the user has entered invalid input
			{
				//clear the scanner
				input.next();
				//check if the user wants to keep going or exit the program. If the user aborts, return -1
				if(checkInput("Invalid Input. Any input - Try again, 1 - quit", "1", input))
				{
					return -1;
				}
				//The user has opted to try again, so reprint the question
				System.out.println(title);
			}
		}
	}
	
	/**
	 * Prompts a user for input and checks if the input matches the supplied string
	 * @param msg String, The message to print to the console
	 * @param checkMsg  String, the string to check input against
	 * @param input Scanner, input stream
	 * @return Boolean, true for equality else false
	 * @author A00184128 - Daniel Rogers
	 */
	public static boolean checkInput(String msg, String checkMsg, Scanner input)
	{
		System.out.println(msg);
		if (input.next().equals(checkMsg))
		{
			return true;
		}
		return false;
	}
	
	/**
	 * Asks the user for a password and allows the user to retry if incorrect
	 * @param text String, the text to display to prompt the user to enter a password
	 * @param in Scanner, the input stream
	 * @param password String, the password to check
	 * @return true if correct, false if the user failed to supply a valid password
	 * @author Daniel Rogers - A00184128
	 */
	public static boolean checkPassword(String text, Scanner in, String password)
	{
		while(true)
		{
			//Max length of password is 10
			if (getStringFromUser(text, in, 10).equalsIgnoreCase(password))
			{
				System.out.println("Password correct");
				return true;
			}
			else
			{
				//if the user wants to try again, restart the loop and don't ask for menu option
				if(CinemaMethods.checkInput("Password incorrect. 0 - Try again, 1 - quit", "0", in))
				{
					continue;
				}
				else
					//go back to the main menu
				{
					return false;
				}
			}
		}
	}
	
	/**
	 * Ask the user for a string
	 * @param title String, the message to print to the console asking the user for input
	 * @param input Scanner, the input stream
	 * @param maxChars the maximum amount of characters accepted. If this limit is exceeded, the user gets a chance to retry
	 * @return A string, or "-1" (in string format) if the user has selected the quit option. 
	 * Note that this method does not handle quit  option functionality; it simply informs the 
	 * caller that the user has selected to quit. 
	 * The caller must decide what to do with this information e.g abort the program
	 * altogether, or return to a previous menu
	 * @author A00184128 - Daniel Rogers
	 */
	public static String getStringFromUser(String title, Scanner input, int maxChars)
	{
		//print info to user
		System.out.println(title);
		//clear the scanner
		input.nextLine();
		String s;
		while(true)
		{
			//get input from user
			if(input.hasNextLine())
			{
				s = input.nextLine();
				if (s.length() > maxChars)
				{				
					//check if the user wants to keep going or exit the program. If the user aborts, return -1
					if(checkInput("Invalid Input (too long). 0 - Try again, any other input - quit", "1", input))
					{
						return "-1";
					}
					//The user has opted to try again, so reprint the question
					System.out.println(title);
					input.nextLine();
				}
				else
				{
					return s;
				}
			}
		}
	}
}
