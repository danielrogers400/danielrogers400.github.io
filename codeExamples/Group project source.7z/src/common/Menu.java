package common;
import java.util.Scanner;

/**
 * This class represents a menu in the menu system
 * @author Daniel
 *
 */
public abstract class Menu 
{
	//the name of the menu
	private String title;
	
	public Menu(String title)
	{
		this.title = title;
	}
	
	public void printTitle()
	{
		System.out.println(title + "\n");
	}
	
	/**
	 * Finds the next menu to navigate to, and does any work associated with the current menu.
	 * This must be implemented with the set of options relevant to the current menu
	 * @param in Scanner, input stream
	 * @return The next menu to navigate to, or null if the user wants to exit to the central menu
	 */
	public abstract Menu getNextMenu(Scanner in);
}
