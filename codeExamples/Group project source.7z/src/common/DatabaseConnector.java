package common;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import AdminSetupStuff.Db_Film;
import AdminSetupStuff.Db_Screen;
import AdminSetupStuff.Db_TimeSlot;

public class DatabaseConnector 
{
	private static Connection con = null;
	private static Statement stmt = null;
	private ResultSet rs = null;
	private String dbName;

	public DatabaseConnector(String name)
	{
		this.dbName = name;
	}

	/**
	 * Connects to the mysql root
	 * @return true if successful, else false with error details
	 * @author Daniel Rogers- A00184128
	 */
	public boolean connect()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String url = "jdbc:mysql://localhost";
			con = DriverManager.getConnection(url, "root", "admin");
			stmt = con.createStatement();
			System.out.println("Connected to SQL");
			return true;
		}
		catch (Exception e)
		{
			System.out.println("Error: Failed to connect to SQL\n" + e.getMessage());
			return false;
		}
	}

	/**
	 * Sets the current selected database, or if it doesn't exist, creates it.
	 * It a new database must be created, it is initialised.
	 * @param name The name of the database
	 * @author Daniel Rogers - A00184128
	 */
	public void setCurrentDatabase()
	{
		boolean databaseExists = false;
		String command = "create database " + this.dbName + ";";
		System.out.println("Setting database...");
		try 
		{
			stmt.execute(command);
			System.out.println("\tDatabase did not exist, creating new one.");
		} 
		catch (SQLException e) 
		{
			System.out.println("\tDatabase already exists.");
			databaseExists = true;
		}

		try 
		{
			stmt.execute("use " + this.dbName + ";");
			System.out.println("\tSetting "+ this.dbName + " to selected database");
			if(!databaseExists)
			{
				initialiseDatabase();
			}
		} 
		catch (SQLException e) 
		{
			System.out.println("\tCannot use database: " + e.getMessage());
		}
	}

	/**
	 * Performs first-time setup on the database
	 * @author Daniel Rogers - A00184128
	 */
	public void initialiseDatabase()
	{
		System.out.println("Initialising database...");
		//all creates must be in separate execute calls, otherwise sql will throw syntax errors
		String s1 = "create table screenTable( " +
				"screen_id integer auto_increment not null primary key," +
				"timeSlot_1 integer not null," +
				"timeSlot_2 integer not null," +
				"timeSlot_3 integer not null);";
		String s2 = "create table timeSlotTable(" +
				"timeSlot_id integer auto_increment not null primary key," +
				"film_id integer not null," +
				"free_seats integer not null," +
				"booked_seats integer not null," +
				"associatedTime varchar(5) not null);\n";
		String s3 = "create table filmTable(" +
				"film_id integer auto_increment not null primary key," +
				"filmName varchar(40) not null," +
				"lengthOfFilm integer not null);";
		String s4 = "create table password(" +
					"pword varchar(10) not null);";
		try {
			stmt.execute(s1);
			stmt.execute(s2);
			stmt.execute(s3);
			stmt.execute(s4);
		} 
		catch (SQLException e) 
		{
			System.out.println("\tThe database could not be initialised\n" + e.getMessage());
			e.printStackTrace();
		}
		//(Re)set the password here
		System.out.println("Setting password to \"Password\"...");
		this.setPassword("Password");
		System.out.println("\tPassword set to " + this.getPassword());
		
	}

	/**
	 * Attempts to remove the database from the system
	 * @param name the name of the database to remove
	 * @author A00184128 - Daniel Rogers
	 */
	public void wipeDatabase()
	{
		System.out.println("Wiping database");
		try 
		{
			System.out.println("\tAttempting to drop database");
			stmt.execute("drop database " + this.dbName + ";");
			System.out.println("\tDatabase dropped");
		} 
		catch (SQLException e) 
		{
			System.out.println("\tCould not drop the database: " + e.getMessage());
			//e.printStackTrace();
		}
	}

	/**
	 * Completely empties the database, by wiping it and re-creating it
	 */
	public void resetDatabase()
	{
		System.out.println("Reseting database...");
		wipeDatabase();
		setCurrentDatabase();
		System.out.println("\tDatabase reset complete");
	}

	/**
	 * Disconnects from the database
	 * @author Daniel Rogers - A00184128
	 */
	public void disconnect()
	{
		System.out.println("Disconnecting from database...");
		try
		{
			con.close();
		}
		catch (SQLException sqle)
		{
			System.out.println("\tError disconnecting: \n" + sqle.getMessage());
		}
		System.out.println("\tDisconnected");
	}

	/**
	 * Adds screen entries to the screenTable in the database
	 * @param screensList ArrayList of screen objects, from which database entries will be generated
	 * @author Daniel Rogers - A00184128
	 */
	public void addScreens(ArrayList<Db_Screen> screensList)
	{
		String str = "";
		for(Db_Screen s : screensList)
		{
			try 
			{
				str = "insert into screenTable values(" + s.toString() + ");";
				stmt.execute(str);
				System.out.println("Added screen with properties: " + s.toString());
			} 
			catch (SQLException e) 
			{
				System.out.println("\tError adding screen: \n" + e.getMessage());
			}
		}
	}

	/**
	 * Remove a screen from the screenTable
	 * @param id The id of the screen to remove
	 * @author A00184128 - Daniel Rogers
	 */
	public void removeScreen(int id)
	{
		try 
		{
			String str = "delete from screenTable where screen_id = " + id;
			stmt.execute(str);
		} 
		catch (SQLException e) 
		{
			System.out.println("\tError deleting screen: \n" + e.getMessage());
		}
	}
	
	/**
	 * Adds time slot entries to the timeSlotTable in the database
	 * @param slotsList ArrayList of Db_TimeSlot objects, from which database entries will be generated
	 * @author Daniel Rogers - A00184128
	 */
	public void addTimeSlots(ArrayList<Db_TimeSlot> slotsList)
	{		
		String str = "";
		for(Db_TimeSlot s : slotsList)
		{
			try 
			{
				str = "insert into timeSlotTable values(" + s.toString() + ");";
				stmt.execute(str);
				System.out.println("Added time slot with properties: " + s.toString());
			} 
			catch (SQLException e) 
			{
				System.out.println("\tError adding time slot: \n" + e.getMessage());
			}
		}
	}

	/**
	 * Remove a time slot from the timeSlotTable
	 * @param id The id of the slot to remove
	 * @author A00184128 - Daniel Rogers
	 */
	public void removeTimeSlot(int id)
	{		
		try 
		{
			String str = "delete from timeSlotTable where timeSlot_id = " + id;
			stmt.execute(str);
		} 
		catch (SQLException e) 
		{
			System.out.println("\tError deleting time slot: \n" + e.getMessage());
		}
	}
	
	
	/**
	 * Checks if the database exists on the system
	 * @return True if exists, else false
	 * @author a00184128 Daniel Rogers
	 */
	public boolean databaseExists(String name)
	{
		String query = "show databases";
		String result = "";
		try 
		{
			rs = stmt.executeQuery(query);
			//Keep looping while there are more entries in the database
			while (!rs.isLast())
			{
				rs.next();
				result = rs.getString("Database");
				if (name.equalsIgnoreCase(result))
				{
					return true;
				}
			} 
			return false;
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * Gets a java object representing a time slot table entry from the database. Editing the java object will
	 * have no effect on the database until it is re-wrote
	 * @param id The ID of the time slot table entry
	 * @return Db_TimeSlot object representing time slot table entry, null if theres an error
	 * @author A00184128 - Daniel Rogers
	 */
	public Db_TimeSlot getTimeSlotFromDb(int id)
	{
		Db_TimeSlot foo = new Db_TimeSlot();
		foo.setID(id);
		String filmIDQuery = "select film_id as f from timeslottable where timeslot_id = " + id;
		String freeSeatsQuery = "select free_seats as f from timeslottable where timeslot_id = " + id;
		String bookedSeatsQuery = "select booked_seats as f from timeslottable where timeslot_id = " + id;
		String timeQuery = "select associatedtime as f from timeslottable where timeslot_id = " + id;
		
		try 
		{
			rs = stmt.executeQuery(filmIDQuery);
			//All selections are selected "as f"
			rs.next();
			foo.setFilmID(rs.getInt("f"));
			
			rs = stmt.executeQuery(bookedSeatsQuery);
			rs.next();
			foo.setBookedSeats(rs.getInt("f"));
			
			rs = stmt.executeQuery(freeSeatsQuery);
			rs.next();
			foo.setFreeSeats(rs.getInt("f"));
			
			rs = stmt.executeQuery(timeQuery);
			rs.next();
			foo.setStartTime(rs.getString("f"));
			return foo;
			
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets a java object representing a screen table entry from the database. Editing the java object will
	 * have no effect on the database until it is re-wrote
	 * @param id The ID of the screen table entry
	 * @return Db_Screen object representing time slot table entry, null if theres an error
	 * @author A00184128 - Daniel Rogers
	 */
	public Db_Screen getScreenFromDb(int id)
	{
		Db_Screen foo = new Db_Screen();
		foo.setID(id);
		String timeSlot1Query = "select timeSlot_1 as f from screentable where screen_id = " + id;
		String timeSlot2Query = "select timeSlot_2 as f from screentable where screen_id = " + id;
		String timeSlot3Query = "select timeSlot_3 as f from screentable where screen_id = " + id;
		
		try 
		{
			rs = stmt.executeQuery(timeSlot1Query);
			//All selections are selected "as f"
			rs.next();
			foo.setTimeSlot1ID(rs.getInt("f"));
			
			rs = stmt.executeQuery(timeSlot2Query);
			rs.next();
			foo.setTimeSlot2ID(rs.getInt("f"));
			
			rs = stmt.executeQuery(timeSlot3Query);
			rs.next();
			foo.setTimeSlot3ID(rs.getInt("f"));
			return foo;
			
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Gets a java object representing a film table entry from the database. Editing the java object will
	 * have no effect on the database until it is re-wrote
	 * @param id The ID of the film table entry
	 * @return Db_Screen object representing time slot table entry, null if theres an error
	 * @author A00184128 - Daniel Rogers
	 */
	public Db_Film getFilmFromDb(int id)
	{
		Db_Film foo = new Db_Film();
		foo.setID(id);
		String filmNameQuery = "select filmName as f from filmtable where film_id = " + id;
		String lengthQuery = "select lengthOfFilm as f from filmtable where film_id = " + id;
		
		try 
		{
			rs = stmt.executeQuery(filmNameQuery);
			rs.next();
			foo.setFilmName(rs.getString("f"));
			
			rs = stmt.executeQuery(lengthQuery);
			rs.next();
			foo.setLengthOfFilm(rs.getInt("f"));
			return foo;
			
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Updates the corresponding db film entry for the object provided
	 * @param f The Db_Film object representing a film entry
	 * @author A00184128 - Daniel Rogers
	 */
	public void writeUpdateToDatabase(Db_Film f)
	{
		int id = f.getID();
		String name = f.getFilmName();
		int length = f.getLengthOfFilm();
		
		String query = "Update filmtable set filmname = \"" + name + "\", lengthoffilm = " + length +
				" where film_id = " + id;
		try 
		{
			stmt.execute(query);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates the corresponding db screen entry for the object provided
	 * @param f The Db_Screen object representing a screen entry
	 * @author A00184128 - Daniel Rogers
	 */
	public void writeUpdateToDatabase(Db_Screen f)
	{
		int id = f.getID();
		int timeSlot1ID = f.getTimeSlot1ID();
		int timeSlot2ID = f.getTimeSlot2ID();
		int timeSlot3ID = f.getTimeSlot3ID();
		
		String query = "Update screentable set timeSlot_1 = " + timeSlot1ID + ", timeSlot_2 = " + 
						timeSlot2ID + ", timeSlot_3  = " + timeSlot3ID +
				" where screen_id = " + id;
		try 
		{
			stmt.execute(query);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates the corresponding db time slot entry for the object provided
	 * @param f The Db_TimeSlot object representing a screen entry
	 * @author A00184128 - Daniel Rogers
	 */
	public void writeUpdateToDatabase(Db_TimeSlot f)
	{
		int id = f.getID();
		int filmID = f.getFilmID();
		int freeSeats = f.getFreeSeats();
		int bookedSeats = f.getBookedSeats();
		String startTime = f.getStartTime();
		
		String query = "Update timeSlotTable set film_id  = " + filmID + ", free_seats  = " + 
				freeSeats + ", booked_seats   = " + bookedSeats + ", associatedTime = \"" + startTime +
				"\" where timeSlot_id = " + id;
		try 
		{
			stmt.execute(query);
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Adds film entries to the filmTable in the database
	 * @param filmsList ArrayList of Db_Film objects, from which database entries will be generated
	 * @author Daniel Rogers - A00184128
	 */
	public void addFilms(ArrayList<Db_Film> filmsList)
	{		
		String str = "";
		for(Db_Film s : filmsList)
		{
			try 
			{
				str = "insert into filmTable values(" + s.toString() + ");";
				stmt.execute(str);
				System.out.println("Added film with properties: " + s.toString());
			} 
			catch (SQLException e) 
			{
				System.out.println("\tError adding film: \n" + e.getMessage());
			}
		}
	}
	
	/**
	 * Remove a film from the timeSlotTable
	 * @param id The id of the slot to remove
	 * @author A00184128 - Daniel Rogers
	 */
	public void removeFilm(int id)
	{		
		try 
		{
			String str = "delete from filmTable where film_id = " + id;
			stmt.execute(str);
		} 
		catch (SQLException e) 
		{
			System.out.println("\tError deleting film: \n" + e.getMessage());
		}
	}
	/**
	 * Displays the film table
	 * @author A00186219 - Niall Stenson, A00184128 - Daniel Rogers
	 * @throws SQLException 
	 */
	public boolean displayFilmTable() throws SQLException
	{
		String query = "select * from filmtable";
		//Find out if the table is empty or not
		rs = stmt.executeQuery(query);
		
		//if rs returns false, table empty
		boolean isEmpty;
		if(!rs.next())
		{
			isEmpty = true;
		}
		else
		{
			isEmpty = false;
		}

		if (isEmpty == false)
		{
			//Find out how many entries are in the table
			int counter = 0;
			String countQuery = "select count(*) from filmtable";
			rs = stmt.executeQuery(countQuery);
			rs.next();
			counter = rs.getInt(1);
			
			//Print table header
			System.out.printf("%-8s%-30s%-6s", "Film ID ", "Film Name", "Length");
			System.out.println();
			//Loop for entries in table and print results
			for (int i = 1; i <= counter; i++)
			{
				Db_Film displayFilm = getFilmFromDb(i);
				System.out.printf("%-7s%-30s%-6s", displayFilm.getID() + " ", displayFilm.getFilmName(), displayFilm.getLengthOfFilm());
				System.out.println();
			}
			return true;
		}

		else
		{
			System.out.println("The table is empty. Returning to outer menu.");
			return false;
		}
	}

	/**
	 * Displays the screen table
	 * @author A00186219 - Niall Stenson, A00184128 - Daniel Rogers
	 * @throws SQLException 
	 */
	public boolean displayScreenTable() throws SQLException
	{
		String query = "select * from screentable";
		//Find out if the table is empty or not
		rs = stmt.executeQuery(query);
		//if rs returns false, table empty
		boolean isEmpty;
		if(!rs.next())
		{
			isEmpty = true;
		}
		else
		{
			isEmpty = false;
		}

		if (isEmpty == false)
		{
			//Find out how many entries are in the table
			String countQuery = "select count(*) from screentable";
			int counter = 0;
			rs = stmt.executeQuery(countQuery);
			rs.next();
			counter = rs.getInt(1);

			//Print table header
			System.out.printf("%-10s%-7s%-7s%-7s", "Screen ID ", "Slot 1", "Slot 2", "Slot3");
			System.out.println();
			//Loop for entries in table and print results
			for (int i = 1; i <= counter; i++)
			{
				Db_Screen displayScreen = getScreenFromDb(i);
				System.out.printf("%-10s%-7s%-7s%-7s", displayScreen.getID() + " ", displayScreen.getTimeSlot1ID(), displayScreen.getTimeSlot2ID(), displayScreen.getTimeSlot3ID());
				System.out.println();
			}
			return true;
		}

		else
		{
			System.out.println("The table is empty. Returning to outer menu.");
			return false;
		}
	}

	/**
	 * Displays the timeslot table
	 * @return false if fails, otherwise true
	 * @author A00186219 - Niall Stenson
	 * @throws SQLException 
	 */
	public boolean displayTimeSlotTable() throws SQLException
	{
		String query = "select * from timeslottable";
		//Find out if the table is empty or not
		rs = stmt.executeQuery(query);
		//if rs returns false, table empty
		boolean isEmpty;
		if(!rs.next())
		{
			isEmpty = true;
		}
		else
		{
			isEmpty = false;
		}

		if (isEmpty == false)
		{
			String countQuery = "select count(*) from timeslottable";
			int counter = 0;
			rs = stmt.executeQuery(countQuery);
			rs.next();
			counter = rs.getInt(1);
			
			//Print table header
			System.out.printf("%-8s%-8s%-11s%-13s%-11s", "Slot ID ", "Film ID", "Free Seats", "Booked Seats", "Start Time");
			System.out.println();
			//Loop for entries in table and print results
			for (int i = 1; i <= counter; i++)
			{
				Db_TimeSlot displaySlot = getTimeSlotFromDb(i);
				System.out.printf("%-8s%-8s%-11s%-13s%-11s", displaySlot.getID(), displaySlot.getFilmID(), displaySlot.getFreeSeats(), displaySlot.getBookedSeats(), displaySlot.getStartTime());
				System.out.println();
			}
			return true;			
		}
		
		else
		{
			System.out.println("The table is empty. Returning to outer menu.");
			return false;
		}
	}
	
	/**
	 * Gets the password from the database
	 * @return The password
	 * @author A00184128 - Daniel Rogers
	 */
	public String getPassword()
	{
		String query = "select pword from password";
		try 
		{
			rs = stmt.executeQuery(query);
			rs.next();
			return rs.getString("pword");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return "null";
	}
	
	/**
	 * Sets the password on the database
	 * @param pword
	 */
	public void setPassword(String pword)
	{
		boolean firstTime = false;
		String query = "select * from password";
		//Find out if the table is empty or not
		try 
		{
			rs = stmt.executeQuery(query);
			//if rs returns false, table empty
			if(!rs.next())
			{
				firstTime = true;
			}
			else
			{
				firstTime = false;
			}
		} 
		catch (SQLException e)
		{
			System.out.println("Error checking table");
			e.printStackTrace();
		}
		//If the table is empty insert a new value, otherwise replace the existing
		if (firstTime)
		{
			query = "insert into password values (\"" + pword + "\")";
		}
		else
		{
			query = "update password set pword = \"" + pword + "\"";
		}
		try
		{
			stmt.execute(query);
		}
		catch (SQLException e)
		{
			System.out.println("Error checking table");
			e.printStackTrace();
		}
	}
	
	/**
	 * Reserves tickets and updates free/booked seats in database
	 * @author A00181047 - Sinead Kelly
	 * @param tickets
	 * @param id
	 */
	public void ReserveTickets(Scanner in, int id)
	{
		int noTickets;
		int filmId = id;
		int freeseats;
		int newFreeSeats;
		int bookedseats;

		try 
		{
			//If UserBoundCheck returns false
			if(!UserBoundCheck(filmId))
			{
				System.out.println("Film ID is invalid.");
				return;
			}
			else
			{
				//Get number of free seats
				rs = stmt.executeQuery("select free_seats as count from timeSlotTable where film_id=" + filmId + ";");
				rs.next();
				freeseats = rs.getInt("count");

				//Inform user of number of available seats
				System.out.println("Available seats: " + freeseats);

				//Ask user for number of tickets
				noTickets = CinemaMethods.getIntFromUser("How many tickets do you wish to book?: ", in);
				//If it is less than 0, it is invalid
				if(noTickets <= 0)
				{
					System.out.println("Error, invalid selection.");
					return;
				}

				//Get number of booked seats
				rs = stmt.executeQuery("select booked_seats as count from timeSlotTable where film_id=" + filmId + ";");
				rs.next();
				bookedseats = rs.getInt("count");

				//If there are less booked seats than user wants to book
				if (freeseats < noTickets)
				{
					//Print out error
					System.out.println("Sorry, those seats are unavailable.");
					return;
				}
				//Else if there are enough free seats
				else if (freeseats >= noTickets)
				{
					//Calculate new free seats
					newFreeSeats = freeseats - noTickets;
					//Calculate new booked seats
					bookedseats += noTickets;
					//Update free seats in database
					String updateFree = "update timeSlotTable set free_seats=" + newFreeSeats + " where film_id=" + filmId + ";";
					stmt.execute(updateFree);
					//Update booked seats in database
					String updateBooked = "update timeSlotTable set booked_seats=" + bookedseats + " where film_id=" + filmId + ";";
					stmt.execute(updateBooked);
					//Confirm booking
					System.out.println("Your tickets have been reserved.");
					return;
				}
			}
		} 

		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

	/**
	 * Cancels tickets and updates free/booked seats in database
	 * @author A00181047 - Sinead Kelly
	 * @param tickets
	 * @param id
	 */
	public void CancelTickets(Scanner in, int id)
	{
		int noTickets;
		int filmId = id;
		int freeSeats = 0;
		int newFreeSeats = 0;
		int bookedSeats = 0;
		try 
		{
			//If UserBoundCheck returns false
			if(!UserBoundCheck(filmId))
			{
				System.out.println("Film ID is invalid.");
				return;
			}
			else
			{
				//Get number of free seats
				rs = stmt.executeQuery("select free_seats as countFree from timeSlotTable where film_id=" + filmId + ";");
				rs.next();
				freeSeats = rs.getInt("countFree");

				//Get number of booked seats
				rs = stmt.executeQuery("select booked_seats as countBooked from timeSlotTable where film_id=" + filmId + ";");
				rs.next();
				bookedSeats = rs.getInt("countBooked");

				//Print out number of booked seats
				System.out.println("There are " + bookedSeats + " seats booked");

				//Ask user for number of tickets
				noTickets = CinemaMethods.getIntFromUser("How many tickets do you wish to cancel?: ", in);
				//If it is less than 0, it is invalid
				if(noTickets <= 0)
				{
					System.out.println("Error, invalid selection.");
					return;
				}


				//If there are less booked seats than user wants to cancel
				if (bookedSeats < noTickets)
				{
					//Print out error
					System.out.println("Error");
					return;
				}
				//Else
				else if (bookedSeats >= noTickets)
				{
					//Calculate new free seats
					newFreeSeats = freeSeats + noTickets;
					//Calculate new booked seats
					bookedSeats -= noTickets;
					//Update free seats in database
					String updateFree = "update timeSlotTable set free_seats=" + newFreeSeats + " where film_id=" + filmId + ";";
					stmt.execute(updateFree);
					//Update booked seats in database
					String updateBooked = "update timeSlotTable set booked_seats=" + bookedSeats + " where film_id=" + filmId + ";";
					stmt.execute(updateBooked);
					//Confirm cancellation
					System.out.println("Your tickets have been cancelled.");
					return;
				}
			}
		} 

		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	/**
	 * Displays films and times
	 * @author A00181047 - Sinead Kelly
	 * @throws SQLException
	 */

	public void displayFilmsAndTimes() throws SQLException
	{
		//Check if table is empty
		String query = "select * from filmtable";
		rs = stmt.executeQuery(query);
		//If rs returns false, table is empty
		boolean isEmpty;
		if(!rs.next())
		{
			isEmpty = true;
		}
		else
		{
			isEmpty = false;
		}

		if (isEmpty == false)
		{
			/*String query2 = "select film_id from filmtable";
			int counter = 1;
			rs = stmt.executeQuery(query2);
			rs.next();
			//While there are more entries in the database
			while (!rs.isLast())
			{
				//Display film details
				rs.next();
				Db_Film displayFilm = getFilmFromDb(counter);
				Db_TimeSlot displayTimeSlot = getTimeSlotFromDb(counter);
				System.out.println(displayFilm.getID() + " " + displayFilm.getFilmName() + " " + displayTimeSlot.getStartTime() + "\n");
				//Increase counter
				counter++;
			} 
			//If it is last entry
			if (rs.isLast())
			{
				//Display film details
				rs.next();
				Db_Film displayFilm = getFilmFromDb(counter);
				Db_TimeSlot displayTimeSlot = getTimeSlotFromDb(counter);
				System.out.println(displayFilm.getID() + " " + displayFilm.getFilmName() + " " + displayTimeSlot.getStartTime() + "\n");
			}	
			
			*/
			
			//Find out how many entries are in the table
			int counter = 0;
			String countQuery = "select count(*) from filmtable";
			
			rs = stmt.executeQuery(countQuery);
			rs.next();
			counter = rs.getInt(1);
			
			//Print table header
			System.out.printf("%-8s%-30s%-10s", "Film ID ", "Film Name", "Start Time");
			System.out.println();
			//Loop for entries in table and print results
			for (int i = 1; i <= counter; i++)
			{
				Db_Film displayFilm = getFilmFromDb(i);
				String timeSlotQuery = "select timeSlot_id from timeslottable where film_id = " + i;
				rs = stmt.executeQuery(timeSlotQuery);
				if(rs.next())
				{
				int timeSlotId = rs.getInt(1);
				Db_TimeSlot displayTimeSlot = getTimeSlotFromDb(timeSlotId);
				
				System.out.printf("%-7s%-30s%-6s", displayFilm.getID() + " ", displayFilm.getFilmName(), displayTimeSlot.getStartTime());
				System.out.println();
				}
			}
		}

		else
		{
			System.out.println("The table is empty. Returning to outer menu.");
		}
	}

	/**
	 * Checks whether the user entered film id is a valid ID
	 * @author A00181047 - Sinead Kelly
	 * @param id
	 * @return
	 */
	public boolean UserBoundCheck(int id)
	{
		int filmId = id;
		int idCount = 0;

		try 
		{
			//Gets the number of film IDs
			rs = stmt.executeQuery("select count(film_id) as count from timeSlotTable;");
			rs.next();
			idCount = rs.getInt("count");
		} 

		catch (SQLException e) 
		{
			e.printStackTrace();
		}

		//If the user entered ID is less than the number of film IDs or less than 0
		if(filmId > idCount || filmId < 0)
		{
			//Returns false
			return false;
		}
		else
		{
			//Else it returns true
			return true;
		}
	}
}
