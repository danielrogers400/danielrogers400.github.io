package user;

import java.sql.SQLException;
import java.util.Scanner;
import common.CinemaMethods;
import common.CinemaSystemException;
import common.DatabaseConnector;
/**
 * 
 * @author A00181047 - Sinead Kelly
 *
 */
public class User 
{
	private DatabaseConnector dbc;
	
	public void userMain(Scanner in, String dbName) throws CinemaSystemException
	{
		dbc = new DatabaseConnector(dbName);
		if(dbc.connect())
		{
			this.dbc.setCurrentDatabase();
		}
		else
		{
			throw new CinemaSystemException("Could not connect to the database");
		}
		
		while(true)
		{	
			//Print menu options to user
			int userInput = CinemaMethods.getIntFromUser("1  - View films and times\n2  - Reserve tickets\n3  - Cancel tickets\n-1 - Quit", in);

			//If user enters 1
			if(userInput == 1)
			{
				//Display films
				try 
				{
					dbc.displayFilmsAndTimes();
				} 
				
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
			
			//If user enters 2
			else if(userInput == 2)
			{
				//Print out confirmation of selection of ticket reservation
				System.out.println("Reserve tickets");
				int filmSelection = 0;
				
				//Ask user for film ID
				filmSelection = CinemaMethods.getIntFromUser("Enter film ID or -1 to quit: ", in);
				
				//If user enters -1, quit
				if(filmSelection == -1)
				{
					return;
				}
				//Call reserve tickets function, pass film selection to it
				dbc.ReserveTickets(in, filmSelection);
				
			}
			
			//If user enters 3
			else if(userInput == 3)
			{
				//Print out confirmation of selection of ticket cancellation
				System.out.println("Cancel tickets");
				int filmSelection = 0;

				//Ask user for film ID
				filmSelection = CinemaMethods.getIntFromUser("Enter film ID or -1 to quit: ", in);
				
				//If user enters -1, quit
				if(filmSelection == -1)
				{
					return;
				}
				
				//Call cancel tickets function, pass film selection to it
				dbc.CancelTickets(in, filmSelection);

				
			}
			
			//If user entered -1, quit to main menu
			else if(userInput == -1)
			{
				return;
			}
			
			//Else user has entered invalid input
			else
			{
				System.out.println("Invalid Input");
				continue;
			}
		}
	}
}
