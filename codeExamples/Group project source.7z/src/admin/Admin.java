package admin;

import java.sql.SQLException;
import java.util.Scanner;

import AdminSetupStuff.Db_Film;
import AdminSetupStuff.Db_TimeSlot;

import common.CinemaMethods;
import common.CinemaSystemException;
import common.DatabaseConnector;

/**
 * 
 * @author A00186219 - Niall Stenson
 *
 */
public class Admin
{
	private DatabaseConnector dbc;

	public void adminMain(String dbName, Scanner in)
	{
		boolean keepGoing = true;

		dbc = new DatabaseConnector(dbName);
		dbc.connect();
		if(dbc.databaseExists(dbName))
		{
			this.dbc.setCurrentDatabase();
		}
		else
		{
			System.out.println("Could not connect to the database (Use Setup to restore/create the database)");
			dbc.disconnect();
			return;
		}

		//if the user doesn't enter a correct password, go back to the main menu
		//otherwise, carry on
		if(!CinemaMethods.checkPassword("Now in Admin setup. Enter Admin password:", in, dbc.getPassword()))
		{
			dbc.disconnect();
			return;
		}

		while(keepGoing)
		{
			//Asking for input
			int input = CinemaMethods.getIntFromUser("In Admin menu. Options:\n" +
					"1  - Change films being shown in screens\n" +
					"2  - Change time of film\n" +
					"3  - Print db details\n" +
					"-1 - Quit", in);

			//Initialising variables
			int changeFilmInput = 0;
			String changeFilmInput2 = "";
			int changeFilmInput3 = 0;

			int changeTimeInput = 0;

			//Start of outer loop
			if (input == 1)
			{
				//Display film table
				try 
				{
					if(!dbc.displayFilmTable())
					{
						continue;
					}
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
					
				}
				//Getting information from the user
				changeFilmInput = CinemaMethods.getIntFromUser("Provide the film ID of the film you wish to change.", in);

				changeFilmInput2 = CinemaMethods.getStringFromUser("Provide the name of the new film", in, 100);

				changeFilmInput3 = CinemaMethods.getIntFromUser("Provide the length of the new film.\n", in);

				//Using the information to update the database
				Db_Film film = new Db_Film(changeFilmInput3, changeFilmInput2);
				film.setID(changeFilmInput);

				dbc.writeUpdateToDatabase(film);

				//Display film table again
				try 
				{
					if(!dbc.displayFilmTable())
					{
						continue;
					}
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}

			else if (input == 2)
			{
				//Display film table again
				try 
				{
					if(!dbc.displayTimeSlotTable())
					{
						continue;
					}
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}

				//Change times of films
				changeTimeInput = CinemaMethods.getIntFromUser("Provide the film ID of the time you wish to change.", in);

				//Display the films
				changeFilmInput2 = CinemaMethods.getStringFromUser("Provide the time of the new film", in, 6);

				Db_TimeSlot ts = new Db_TimeSlot();
				ts = dbc.getTimeSlotFromDb(changeTimeInput);

				ts.setFilmID(changeTimeInput);
				ts.setStartTime(changeFilmInput2);

				dbc.writeUpdateToDatabase(ts);

				//Display film table again
				try 
				{
					if(!dbc.displayTimeSlotTable())
					{
						continue;
					}
				} 
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}

			else if (input == 3)
			{
				try 
				{
					System.out.println("\nScreen table:");
					dbc.displayScreenTable();
					System.out.println("\nFilm table:");
					dbc.displayFilmTable();
					System.out.println("\nTime slot table:");
					dbc.displayTimeSlotTable();
				} catch (SQLException e) 
				{
					System.out.println("Error printing db info");
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
			else if (input == -1)
			{
				break;
			}
		}
		dbc.disconnect();
	}
}



