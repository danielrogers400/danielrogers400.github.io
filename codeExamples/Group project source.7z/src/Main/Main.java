package Main;
import java.util.Scanner;

import common.CinemaMethods;
import common.CinemaSystemException;

import user.User;

import admin.Admin;

import AdminSetupStuff.AdminSetup;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);

		//The menu to navigate to from the root menu
		int menuInput = 0;
		String password = "f";
		

		while(true)
		{
			//Ask the user which menu to navigate to
			menuInput = CinemaMethods.getIntFromUser("At root menu. Options: \n\n1  - Setup (Perfrom first time setup and low level database actions)\n2  - Admin (Manage existing database entries)\n3  - User (Access public database information)\n-1 - Quit\nEnter your choice: ", in);
			//If the user has decided to quit, exit the program
			if(menuInput == -1)
			{
				break;
			}
			/*
			 ><><>><><><><><><><><><><><><><><><
			 ><><Menu option 1: Admin setup<><><
			 ><><>><><><><><><><><><><><><><><><
			 */ 
			if(menuInput == 1)
			{
				AdminSetup as;
				//try 
				{
					as = new AdminSetup(in);
					as.adminSetupMain(password, "CinemaSystem");
				} 
				//catch (CinemaSystemException e) 
				{
				//	System.out.println(e.getMessage() + "\n\nWill now exit");
				//	break;
				}
			}
			else if(menuInput == 2)
			{
				Admin ad = new Admin();
				ad.adminMain("CinemaSystem", in);
				
			}
			else if(menuInput == 3)
			{
				User user = new User();
				try {
					user.userMain(in, "CinemaSystem");
				} catch (CinemaSystemException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(menuInput == -1)
			{
				break;
			}
		}
		//end of the while
		System.out.println("Quitting");
	}
}
