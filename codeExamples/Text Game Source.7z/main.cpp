#include<string>
#include <iostream>
using namespace std;
#include "Room.h"
#include "Item.h"
#include "Player.h"

Room* createRooms(int size);
void deleteRooms(Room* roomsArrayPtr, int numberOfRooms);
void populateRooms(Room* roomArrayPtr);
void runGame(Room* roomsArrayPtr, int numberOfRooms);
void prompt();
string getCommand();
bool getActionCommand(Item* currentItem);

void main()
{
	//the number of rooms in the world
	int numberOfRooms = 3;
	//begin by creating the rooms
	Room* roomsArrayPtr = createRooms(numberOfRooms);
	//fill the rooms with items
	populateRooms(roomsArrayPtr);

	//run the game
	runGame(roomsArrayPtr, numberOfRooms);


	cout << "You have exited the game." << endl;
	system("pause");
	deleteRooms(roomsArrayPtr, numberOfRooms);
}

//Returns a dynamic array of rooms according to the size specified.
//The rooms are not properly initialised at this stage - populateRooms must be called immediately
//after this to finish initialisation
Room* createRooms(int size)
{
	return new Room[size];
}

//Deletes all of the memory in use by the rooms
void deleteRooms(Room* roomsArrayPtr, int numberOfRooms)
{
	//begin by deleting the item arrays each room is using
	for(int i = 0; i < numberOfRooms; i++)
	{
		roomsArrayPtr[i].deleteItems();
	}
	//now delete the array of rooms
	delete[] roomsArrayPtr;
	roomsArrayPtr = NULL;
}

//Creates item array and associates them with rooms, as well as finishing room initialisation
void populateRooms(Room* roomArrayPtr)
{

	//<><><><><><><><><><><
	//ROOM 1 - KITCHEN
	//<><><><><><><><><><><	
	//Create a dynamic array here and use it to store Item objects. The memory is deleted
	//by the room object when neccessary
	Item* kitchenItemsArrayPtr = new Item[3];
	kitchenItemsArrayPtr[0].initialise("Book", 0, "The book is open", "The book is closed", "Read it");
	kitchenItemsArrayPtr[1].initialise("T.V", 1, "The tv is on", "The tv is off", "Activate it");
	kitchenItemsArrayPtr[2].initialise("Radio", 2, "The radio is on", "The radio is off", "Activate it");

	//Now create the door array. This array is also deleted in the room's deleteItems method
	Door* kitchenDoorArray = new Door[2];
	kitchenDoorArray[0].initialise(true, "Exit", -1);
	kitchenDoorArray[1].initialise(false, "SittingRoom", 1);

	Room kitchen("Kitchen", 0, kitchenItemsArrayPtr, 3, kitchenDoorArray, 2);
	roomArrayPtr[0] = kitchen;

	//<><><><><><><><><><><
	//ROOM 2 - SITTING ROOM
	//<><><><><><><><><><><
	Item* sRoomItemsArrayPtr = new Item[3];
	sRoomItemsArrayPtr[0].initialise("Magazine", 0, "The Magazine is open", "The Magazine is closed", "Read it");
	sRoomItemsArrayPtr[1].initialise("Jar", 1, "The jar is open", "The jar is closed", "Move the lid");
	sRoomItemsArrayPtr[2].initialise("Cabinet", 2, "The cabinet is open", "The cabinet is closed", "Move the door");
	
	//Now create the door array. This is array is also deleted in the room's deleteItems method
	Door* sRoomDoorArray = new Door[3];
	sRoomDoorArray[0].initialise(true, "Exit", -1);
	sRoomDoorArray[1].initialise(false, "Kitchen", 0);
	sRoomDoorArray[2].initialise(false, "Bathroom", 2);

	Room sRoom("Sitting Room", 1, sRoomItemsArrayPtr, 3, sRoomDoorArray, 3);
	roomArrayPtr[1] = sRoom;
	
	//<><><><><><><><><><><
	//ROOM 3 - BATHROOM
	//<><><><><><><><><><><
	Item* bathroomItemsArrayPtr = new Item[2];
	bathroomItemsArrayPtr[0].initialise("Sink", 0, "The sink is empty", "The sink is full", "Change the water");
	bathroomItemsArrayPtr[1].initialise("Shower", 1, "The shower is off", "The shower is on", "Turn the tap");
		
	//Now create the door array. This is array is also deleted in the room's deleteItems method
	Door* bRoomDoorArray = new Door[3];
	bRoomDoorArray[0].initialise(true, "Exit", -1);
	bRoomDoorArray[1].initialise(false, "Kitchen", 0);
	bRoomDoorArray[2].initialise(false, "SittingRoom", 1);

	Room bRoom("Bathroom", 2, bathroomItemsArrayPtr, 2, bRoomDoorArray, 3);
	roomArrayPtr[2] = bRoom;
}

void runGame(Room* roomsArrayPtr, int numberOfRooms)
{	
	//The player's name
	string playerName;
	//the next command the player enters
	string command;
	//any instructions to go to the player go here.
	string instr = "Please note that all commands are case sensitive.\nTo exit the game, just use any exit door.\n-----------------------------";
	//does the command match an item?
	bool commandMatchesItem;
	bool keepLooping = true;

	cout << "Enter your name:" << endl;
	cin >> playerName;
	cout << "Welcome to the game, " << playerName << endl << instr << endl << endl;

	Player player(playerName);
	player.goToRoom(&roomsArrayPtr[0]);


	while(keepLooping)
	{
		//Find the current room the player is in
		Room* currentRoom = player.getCurrentRoom();
		//print the room details
		cout << "-----------------------" << endl;
		cout << "-----------------------" << endl;
		currentRoom->printDetails();
		//find out where the player wants to go
		command = getCommand();
		//reset this variable 
		commandMatchesItem = false;
		//Loop through all of the items in the current room and see if the player has specified any of them
		//if they have, go to it
		for(int i = 0; i< currentRoom->getItemsArrayLength(); i++)
		{
			Item* item = &currentRoom->getItems()[i];
			if (command == item->getName())
			{
				commandMatchesItem = true;
				//the command is valid, so go to the item
				player.goToItem(item);
				//print out the item details
				cout << endl << item->getDetails() << endl;
				//ask the player for an interaction, and deal with it
				//if the layer wants to exit, break here.
				if(getActionCommand(player.getCurrentItem()) == true)
				{
					keepLooping = false;
					break;
				}
				//print out the items current state (it may have changed due to interaction)
				cout << "\t" << player.getCurrentItem()->getActivationText() << endl << endl;
				//Flip the item visited property, only if it was previously false
				if (!item->isVisited())
				{
					item->setVisited(true);
				}
				break;
			}
		}
		//Loop through all the doors and see if the player wants to move somewhere or exit
		for(int i = 0; i < currentRoom->getDoorArrayLength(); i++)
		{
			Door* door = &currentRoom->getDoorArrayPtr()[i];

			if (door->getName() == command)
			{
				commandMatchesItem = true;
				//if this door is an exit door, then break and exit
				if (door->isExitDoor())
				{
					keepLooping = false;
					break;
				}
				int nextRoomindex = door->getNextRoom();
				for(int i = 0; i < numberOfRooms; i++)
				{
					Room* _nextRoom = &roomsArrayPtr[i];
					if (nextRoomindex == _nextRoom->getRoomIndex())
					{
						player.goToRoom(_nextRoom);
						break;
					}
				}
			}
		}

		if (!commandMatchesItem)
		{
			cout << endl << "I don't know \"" << command << "\"" << endl << endl; 
		}
	}
}

//Gets a command from the player
string getCommand()
{
	cout << "Where would you like to go?\nI would like to go to the: ";
	string command = "";
	cin >> command;
	return command;
}

//Get a command from the player relating to an interaction
//returns true if an exit game command has been specified
bool getActionCommand(Item* currentItem)
{
	string choice;
	cout << "Do you want to " << currentItem->getInteractionText() << " ?(y/n) ";
	cin >> choice;
	cout << endl;
	if(choice == "y")
	{
		currentItem->activate();
	}
	return false;
}