#include "Door.h";

Door::Door(bool exitDoorArg, string nameArg, int nextRoomIndexArg)
{
	exitDoor = exitDoorArg;
	name = nameArg;
	nextRoomIndex = nextRoomIndexArg;
}

Door::Door()
{	
	exitDoor = false;
	name = "";
	nextRoomIndex = 0;
}

void Door::initialise(bool exitDoorArg, string nameArg, int nextRoomIndexArg)
{
	exitDoor = exitDoorArg;
	name = nameArg;
	nextRoomIndex = nextRoomIndexArg;
}

const string Door::getName()
{
	return name;
}

const bool Door::isExitDoor()
{
	return exitDoor;
}

const int Door::getNextRoom()
{
	return nextRoomIndex;
}