#ifndef ITEM_H
#define ITEM_H
#include<string>
using namespace std;

//In game interactable items
class Item
{
public:
	//Creates a new item object with the specified name, actions, number of actions and index
	//Item(string nameArg, Action* actionsArg, int numberofActionsArg, int indexArg, 
		//string activatedTextArg, string deactivatedTextArg);


	Item(string nameArg, int indexArg, string activatedTextArg, string deactivatedTextArg, string interactionTextArg);
	Item();
	//Used when the default constructor is called, as values still need to be properly initialised
	void initialise(string nameArg, int indexArg, string activatedTextArg, string deactivatedTextArg,
		string interactionTextArg);
	//get the name of this item
	const string getName();
	//is the item activated?
	const bool isActivated();
	//(de)activate the item
	void activate();
	//get the activated text
	const string getActivatedText();
	//get the deactivated text
	const string getDeactivatedText();
	//Get the interaction text
	const string getInteractionText();
	//get the item details
	const string getDetails();
	//set the wasVisited variable
	void setVisited(bool visited);
	const bool isVisited();
	const string getActivationText();

private:
	//The name of this item
	string name;
	//The index of this item. Must be unique
	int index;
	//the state of the item, can be used to easily give items more interactions
	bool activated;
	//The text to display when activated
	string activatedText;
	//The text to display when deactivated
	string deactivatedText;
	//string describing the interaction with this object
	string interactionText;
	//has this item been visited?
	bool wasVisited;
	//The details of this item
	string details;
};
#endif