#ifndef PLAYER_H
#define PLAYER_H

#include<string>
using namespace std; 
#include "Room.h"
#include"Item.h"

//The player in the game
class Player
{
public:
	//Constructs an object of this class
	Player(string nameArg);
	//get the players name
	const string getName();
	//Go to a new room
	void goToRoom(Room* destination);
	//Move to an item
	void goToItem(Item* item);
	//Gets a pointer to the current item
	Item* getCurrentItem();
	//Gets a pointer to the current room
	Room* getCurrentRoom();
private:
	//the players name
	string name;
	//pointer to the current room
	Room* currentRoom;
	//pointer to the current item
	Item* currentItem;
	//The next peice of keyboard input
	string keyboardInput;
};

#endif