#include "Item.h"
#include <iostream>

Item::Item(string nameArg, int indexArg, string activatedTextArg, string deactivatedTextArg, string interactionTextArg)
{
	index = indexArg;
	name = nameArg;
	activated = false;
	activatedText = activatedTextArg;
	deactivatedText = deactivatedTextArg;
	wasVisited = false;
	interactionText = interactionTextArg;
}

Item::Item()
{
	index = -1;
	name = "Not Set";
	activated = false;
	activatedText = "Not Set";
	deactivatedText = "Not Set";
	wasVisited = false;
}

void Item::initialise(string nameArg, int indexArg, string activatedTextArg, string deactivatedTextArg,
	string interactionTextArg)
{	
	index = indexArg;
	name = nameArg;
	activated = false;
	activatedText = activatedTextArg;
	deactivatedText = deactivatedTextArg;
	wasVisited = false;
	interactionText = interactionTextArg;
}

const string Item::getInteractionText()
{
	return interactionText;
}

const string Item::getName()
{
	return name;
}

const string Item::getActivationText()
{
	if(activated)
	{
		return activatedText;
	}
	else
	{
		return deactivatedText;
	}
}

const string Item::getDetails()
{
	string s = "";
	if(activated)
	{
		s = activatedText;
	}
	else
	{
		s = deactivatedText;
	}
	if (wasVisited)
	{
		s = s + "\nYou have seen this before\n";
	}
	else
	{
		s = s + "\nYou have not seen this before\n";
	}
	return s;
}

const bool Item::isActivated()
{
	return activated;
}

void Item::activate()
{
	activated = !activated;
}

void Item::setVisited(bool visited)
{
	wasVisited = visited;
}


const bool Item::isVisited()
{
	return wasVisited;
}