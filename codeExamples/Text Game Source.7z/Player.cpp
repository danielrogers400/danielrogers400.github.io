#include"Player.h"
#include<string>
using namespace std;
#include<iostream>
#include "Room.h"

Player::Player(string nameArg)
{
	name = nameArg;
}

const string Player::getName()
{
	return name;
}

void Player::goToRoom(Room* destination)
{
	currentRoom = destination;
	//cout << destination->getTitle() << endl;
}

void Player::goToItem(Item* item)
{
	currentItem = item;
	//item->setVisited(true);
}

Item* Player::getCurrentItem()
{
	return currentItem;
}

Room* Player::getCurrentRoom()
{
	return currentRoom;
}
