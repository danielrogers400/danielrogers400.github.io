#ifndef DOOR_H
#define DOOR_H

#include<string>
using namespace std;

//Handles in game doors
class Door
{
public:
	//Constructor with explicit arguments
	Door(bool exitDoorArg, string nameArg, int nextRoomIndexArg);
	//Default constructor
	Door();
	//Initialise all variables at once, for use with default constructor
	void initialise(bool exitDoorArg, string nameArg, int nextRoomIndexArg);
	//Get the name of this door (i.e where it leads to)
	const string getName();
	//Is this an exit door?
	const bool isExitDoor();
	//Get the index of the next room
	const int getNextRoom();

private:
	bool exitDoor;
	string name;
	int nextRoomIndex;
};

#endif