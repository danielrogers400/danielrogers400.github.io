#ifndef ROOM_H
#define ROOM_H

#include<string>
using namespace std;
#include "Item.h"
#include "Door.h"

//Represents a room in the game world
class Room
{
public:
	//Constructs a room object with the specified title, index, items array, items array length, door array and door array length
	Room(string titleArg, int indexArg, Item* itemsArrayArg, int itemsArraySize, Door* doorArrayPtrArg, int doorArraySize);
	//The default constructor, does not initialise values properly
	Room();
	//cleans up any memory in use by this room - mainly item arrays
	void deleteItems();
	//gets the title of the room
	const string getTitle();
	//gets the itemsArray
	Item* getItems();
	//print the details of this room - it's name and all of the items within it
	const void printDetails();
	//Gets the current room index
	const int getRoomIndex();
	//Get the length of the items array
	const int getItemsArrayLength();
	//get a pointer to the door array
	Door* getDoorArrayPtr();
	//Get the length of the door array
	const int getDoorArrayLength();

private:
	//The name of this room
	string title;
	//A dynamic array containing pointers to all of the items that are in the room
	Item* itemsArray;
	//Length of the itemsArray
	int itemsArrayLength;
	//the index of the room
	int index;
	//A dynamic array containing pointers to all of the doors that are in the room
	Door* doorArrayPtr;
	//the length of the doors array
	int doorArrayLength;
};

#endif