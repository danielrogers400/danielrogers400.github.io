#include<string>
#include "Room.h"
#include<iostream>
using namespace std;

Room::Room(string titleArg, int indexArg, Item* itemsArrayArg, int itemsArraySize, Door* doorArrayPtrArg, int doorArraySize)
{
	title = titleArg;
	index = indexArg;
	itemsArrayLength = itemsArraySize;
	itemsArray = itemsArrayArg;
	doorArrayPtr = doorArrayPtrArg;
	doorArrayLength = doorArraySize;
}

Room::Room()
{
	title = "Not Set";
	index = -1;
	itemsArrayLength = 0;
	itemsArray = NULL;
}

Door* Room::getDoorArrayPtr()
{
	return doorArrayPtr;
}

const int Room::getDoorArrayLength()
{
	return doorArrayLength;
}

const int Room::getItemsArrayLength()
{
	return itemsArrayLength;
}

void Room::deleteItems()
{
	delete[] itemsArray;
	itemsArray = NULL;
	delete[] doorArrayPtr;
	doorArrayPtr = NULL;
}

const string Room::getTitle()
{
	return title;
}

Item* Room::getItems()
{
	return itemsArray;
}

const void Room::printDetails()
{
	//print the room name
	cout << "You are in the " << title << endl << endl << "In front of you you see: " << endl;
	//Loop through all of the items in the room and print their name
	for(int i = 0; i < itemsArrayLength; i++)
	{
		cout << "A " << itemsArray[i].getName();
		if (i == itemsArrayLength - 2)
		{
			cout << " and ";
		}
		else if (i != itemsArrayLength - 1)
		{
			cout << ", ";
		}
		else
		{
			cout << endl;
		}
	}
	cout << "\nYou also see " << doorArrayLength << " door(s) with the following labels: " << endl;

	for (int i = 0; i < doorArrayLength; i++)
	{
		cout << "\t" << doorArrayPtr[i].getName() << endl;
	}
	cout << endl;
}

const int Room::getRoomIndex()
{
	return index;
}